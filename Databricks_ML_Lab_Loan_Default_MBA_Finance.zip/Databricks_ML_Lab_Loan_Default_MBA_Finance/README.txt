CREDIT RISK MACHINE LEARNING LAB — DATABRICKS FREE EDITION
MBA Finance Edition · Predicting Consumer Loan Default
Prepared by Aarvi Learning Solutions
============================================================

WHAT'S IN THIS PACKAGE
----------------------
1. Participant_Lab_Guide.docx   Student-facing guide. Start here. Covers account
                                setup, importing the files, a step-by-step
                                walkthrough, a data dictionary, challenge
                                exercises, troubleshooting, and a glossary.

2. Instructor_Guide.docx        Facilitator's guide: 90-minute session plan,
                                pre-class checklist, teaching notes per step,
                                challenge answer key, pitfalls, and assessment
                                ideas.

3. loan_default_ml_lab.ipynb    The Databricks notebook. Import this into a
                                Databricks Free Edition workspace and run it
                                top to bottom. Every cell is pre-written and
                                commented.

4. loan_applications.csv        The dataset: 2,500 historical consumer loans
                                with a "default" outcome column.

5. data_dictionary.csv          Plain-English description of every column.


QUICK START (5 STEPS)
---------------------
1. Create a free account at:  databricks.com/learn/free-edition
   (No credit card, no cloud account — sign in with email, Google, or Microsoft.)

2. In your workspace: Workspace > Home > (⋮ menu) > Import
   and import  loan_default_ml_lab.ipynb

3. Upload  loan_applications.csv  to a Volume:
   Catalog > workspace > default > Create > Volume  (name it "lab_data"),
   then "Upload to this volume".

4. Open the notebook and run each cell with Shift+Enter, top to bottom.

5. Read the markdown above each cell to interpret the output.

NOTE: If the CSV upload gives you any trouble, don't worry — the notebook
detects a missing file and automatically builds an identical dataset in memory,
so the lab works either way. Just run the first cell and continue.


SCENARIO
--------
You are an analyst on a retail bank's credit-risk team. You will build a model
that estimates each applicant's probability of default, evaluate it the way a
bank does (weighing bad loans approved against good customers rejected), and
translate it into expected loss and a profit-maximising approval cut-off.

Estimated time: about 90 minutes. No prior coding experience required.
