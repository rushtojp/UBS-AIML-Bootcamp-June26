# Fraud Detection on Databricks — Lab Package

**Aarvi Learning Solutions | Machine Learning Lab**

A complete, instructor-led lab that takes participants from a raw, imbalanced
transaction dataset to a cost-tuned fraud model — with the metrics that actually
matter for rare-event problems (precision, recall, PR-AUC, threshold tuning).

Runs end-to-end on **Databricks Free Edition** (single-node, no cost). Duration
~3 hours, intermediate level.

---

## What's in this package

| File | What it is |
|---|---|
| `Fraud_Detection_Lab_Guide.docx` | The main courseware: step-by-step procedure, metrics reference, and instructor notes. Start here. |
| `Course_Planner.xlsx` | Live-timed agenda (edit the start time, everything recalculates), pre-session checklist, and expected-results reference. |
| `transactions.csv` | Synthetic dataset — 55,000 transactions, ~2% fraud. No real customer data. |
| `fraud_detection_STUDENT.ipynb` | Participant workbook with TODOs to complete. |
| `fraud_detection_SOLUTION.ipynb` | Instructor reference — the complete, runnable answer. |
| `fraud_detection_STUDENT.py` | Databricks source-format copy of the student notebook. |
| `fraud_detection_SOLUTION.py` | Databricks source-format copy of the solution notebook. |
| `generate_dataset.py` | The dataset generator, in case you want to reshape the data or make a fresh variant (fixed seed = reproducible). |

Both `.ipynb` and `.py` copies of each notebook are provided. Use whichever
imports more cleanly into your Databricks setup — `.ipynb` via **Workspace →
Import**, `.py` via Repos or Import (Databricks recognises the source format).

---

## Instructor quick start

1. **Prep** (day before): create/confirm Databricks Free Edition accounts, upload
   `transactions.csv` to a volume, import the STUDENT notebook. The full checklist
   is on the *Setup Checklist* tab of `Course_Planner.xlsx`.
2. **Set timings**: open `Course_Planner.xlsx`, edit the yellow start-time cell on
   the *Agenda* tab — all module start/end times recalculate.
3. **Test-run** the SOLUTION notebook end-to-end on the room's environment to catch
   any path or version issues.
4. **Teach** from the Lab Guide. The whole lab hinges on three moments:
   - **Module 5** — the baseline is ~98% accurate and catches almost no fraud.
   - **Module 7** — ROC-AUC looks great (~0.87) while PR-AUC is far lower (~0.31).
   - **Module 9** — the right decision threshold comes from business cost, not 0.5.

---

## The lab in one paragraph

Participants load the data with Spark, quantify the ~2% fraud rate, engineer
domain features (night activity, velocity, large amounts), and train a baseline
logistic regression that looks accurate but is useless. They fix it with class
weighting, learn to judge models on PR-AUC and recall rather than accuracy,
train a stronger random forest, tune the decision threshold on the relative cost
of a missed fraud versus a false alarm, and log the run to MLflow for
reproducibility.

## Expected results (approximate — vary by library version)

| Model | ROC-AUC | PR-AUC | Fraud recall @ 0.5 |
|---|---|---|---|
| Logistic (no weighting) | ~0.87 | ~0.31 | near 0 |
| Logistic (balanced) | ~0.87 | ~0.31 | ~0.75 |
| Random forest (balanced) | ~0.87 | ~0.35 | ~0.55 |

Trends matter, not third decimals.

---

*Synthetic data only. Built for Aarvi Learning Solutions training delivery.*
