# Databricks notebook source
# MAGIC %md
# MAGIC # Fraud Detection on Databricks — Instructor Solution
# MAGIC
# MAGIC **Aarvi Learning Solutions | Machine Learning Lab**
# MAGIC
# MAGIC This notebook is the complete, runnable reference for the fraud-detection lab.
# MAGIC It loads a synthetic transaction dataset, explores the class imbalance,
# MAGIC engineers features, trains and compares models, and — the heart of the lab —
# MAGIC evaluates them with the metrics that actually matter for fraud.
# MAGIC
# MAGIC **Runs on:** Databricks Free Edition / Community, or any single-node cluster
# MAGIC (DBR 13.x ML or later). No GPU required.
# MAGIC
# MAGIC > Estimated run time end-to-end: ~8–10 minutes.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 0 — Setup
# MAGIC
# MAGIC Two things before we start:
# MAGIC 1. Upload `transactions.csv` to the workspace (see the Lab Guide, Step 2).
# MAGIC 2. Point `DATA_PATH` below at wherever you uploaded it.
# MAGIC
# MAGIC On Databricks the file typically lands under `/Volumes/...` (Unity Catalog),
# MAGIC `/FileStore/tables/transactions.csv`, or a workspace path. Adjust as needed.

# COMMAND ----------

# --- Point this at your uploaded file -----------------------------------
# Databricks Free Edition (Unity Catalog volume) example:
# DATA_PATH = "/Volumes/workspace/default/labdata/transactions.csv"
# Classic FileStore example:
# DATA_PATH = "/FileStore/tables/transactions.csv"
# Local / Jupyter fallback:
DATA_PATH = "transactions.csv"

# Detect whether we're on Spark (Databricks) or plain Python (Jupyter)
try:
    spark                      # noqa: F821  provided by Databricks
    ON_DATABRICKS = True
except NameError:
    ON_DATABRICKS = False

print("Running on Databricks Spark:", ON_DATABRICKS)
print("Data path:", DATA_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 1 — Load the data
# MAGIC
# MAGIC We read the CSV into a Spark DataFrame when on Databricks (this is the pattern
# MAGIC you'd use at scale), then work with a pandas copy for modelling and plotting.

# COMMAND ----------

import pandas as pd

if ON_DATABRICKS:
    sdf = (spark.read
                 .option("header", True)
                 .option("inferSchema", True)
                 .csv(DATA_PATH))
    print("Spark row count:", sdf.count())
    sdf.printSchema()
    pdf = sdf.toPandas()
else:
    pdf = pd.read_csv(DATA_PATH)

print("pandas shape:", pdf.shape)
pdf.head()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 2 — Explore & understand the class imbalance
# MAGIC
# MAGIC The single most important fact about a fraud dataset: **the classes are wildly
# MAGIC imbalanced.** Most transactions are legitimate. This shapes every modelling and
# MAGIC metric decision that follows.

# COMMAND ----------

# How rare is fraud?
counts = pdf["is_fraud"].value_counts().sort_index()
rate   = pdf["is_fraud"].mean()
print("Legit (0):", counts.get(0, 0))
print("Fraud (1):", counts.get(1, 0))
print(f"Fraud rate: {rate:.3%}")
print(f"Imbalance ratio ~ 1 fraud : {int((1-rate)/rate)} legit")

# COMMAND ----------

import matplotlib.pyplot as plt

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
counts.plot(kind="bar", ax=ax[0], color=["#4C72B0", "#C44E52"])
ax[0].set_title("Class counts (note the scale)")
ax[0].set_xticklabels(["legit", "fraud"], rotation=0)

# Fraud is easier to see on a log scale
counts.plot(kind="bar", ax=ax[1], color=["#4C72B0", "#C44E52"], logy=True)
ax[1].set_title("Class counts (log scale)")
ax[1].set_xticklabels(["legit", "fraud"], rotation=0)
plt.tight_layout(); plt.show()

# COMMAND ----------

# Data-quality check: any missing values?
missing = pdf.isna().sum()
print(missing[missing > 0])

# COMMAND ----------

# Where does fraud concentrate? Compare fraud RATE across a few dimensions.
def fraud_rate_by(col, top=10):
    g = (pdf.groupby(col)["is_fraud"]
             .agg(["mean", "count"])
             .rename(columns={"mean": "fraud_rate", "count": "n"})
             .sort_values("fraud_rate", ascending=False))
    return g.head(top)

print("By transaction type:\n", fraud_rate_by("txn_type"), "\n")
print("By card_present:\n", fraud_rate_by("card_present"), "\n")
print("By is_foreign:\n", fraud_rate_by("is_foreign"))

# COMMAND ----------

# Amount distribution: fraud tends to sit at higher amounts
import numpy as np
fig, ax = plt.subplots(figsize=(9, 4))
bins = np.linspace(0, pdf["amount"].quantile(0.99), 40)
ax.hist(pdf.loc[pdf.is_fraud == 0, "amount"], bins=bins, alpha=0.6, label="legit", density=True)
ax.hist(pdf.loc[pdf.is_fraud == 1, "amount"], bins=bins, alpha=0.6, label="fraud", density=True, color="#C44E52")
ax.set_xlabel("amount"); ax.set_ylabel("density"); ax.legend()
ax.set_title("Transaction amount by class (density)")
plt.tight_layout(); plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 3 — Feature engineering
# MAGIC
# MAGIC We (1) handle the missing distances, and (2) add a few domain-driven features
# MAGIC that encode the intuition an analyst would have: late-night activity, high
# MAGIC velocity, and large amounts.

# COMMAND ----------

data = pdf.copy()

# 1) Impute missing distance with the median (robust to outliers)
median_dist = data["distance_from_home_km"].median()
data["distance_from_home_km"] = data["distance_from_home_km"].fillna(median_dist)

# 2) Domain features
data["is_night"]        = data["hour"].isin([0, 1, 2, 3, 4, 5]).astype(int)
data["high_velocity"]   = (data["txns_last_24h"] >= 7).astype(int)
data["rapid_repeat"]    = (data["seconds_since_last_txn"] < 300).astype(int)
data["large_amount"]    = (data["amount"] > 600).astype(int)
data["far_from_home"]   = (data["distance_from_home_km"] > 60).astype(int)
data["amount_per_age"]  = data["amount"] / data["customer_age"].clip(lower=18)

print("Engineered columns added.")
data[["is_night","high_velocity","rapid_repeat","large_amount","far_from_home"]].mean()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 4 — Prepare the modelling matrix
# MAGIC
# MAGIC Split features into numeric and categorical, build a preprocessing pipeline
# MAGIC (one-hot for categoricals, scaling for numerics), and make a **stratified**
# MAGIC train/test split so the tiny fraud class is represented in both halves.

# COMMAND ----------

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

target = "is_fraud"
categorical = ["merchant_category", "txn_type"]
numeric = [
    "customer_age", "account_tenure_days", "amount", "card_present",
    "is_foreign", "hour", "txns_last_24h", "distance_from_home_km",
    "seconds_since_last_txn", "is_night", "high_velocity", "rapid_repeat",
    "large_amount", "far_from_home", "amount_per_age",
]

X = data[numeric + categorical]
y = data[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=7
)

preprocess = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
    ("num", StandardScaler(), numeric),
])

print("Train:", X_train.shape, "  fraud in train:", int(y_train.sum()))
print("Test :", X_test.shape,  "  fraud in test :", int(y_test.sum()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 5 — Baseline model, and why accuracy lies
# MAGIC
# MAGIC Train a plain logistic regression with **no** imbalance handling. Its accuracy
# MAGIC will look fantastic — because a model that predicts "legit" for everything is
# MAGIC ~98% accurate here. That is the trap this whole lab exists to expose.

# COMMAND ----------

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

baseline = Pipeline([("prep", preprocess),
                     ("clf", LogisticRegression(max_iter=2000))])
baseline.fit(X_train, y_train)
pred_base = baseline.predict(X_test)

print(f"Accuracy: {accuracy_score(y_test, pred_base):.4f}   <-- looks great, means little")
print("\nConfusion matrix [rows=true, cols=pred]:")
print(confusion_matrix(y_test, pred_base))
print("\n", classification_report(y_test, pred_base, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC Look at the **recall** for class 1. The model catches almost no fraud, yet
# MAGIC accuracy is ~98%. Accuracy is the wrong scoreboard for rare events.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 6 — Handling the imbalance
# MAGIC
# MAGIC The simplest effective fix: tell the model that fraud errors cost more, via
# MAGIC `class_weight="balanced"`. (Resampling with SMOTE is an alternative — noted in
# MAGIC the challenge section.)

# COMMAND ----------

logreg = Pipeline([("prep", preprocess),
                   ("clf", LogisticRegression(max_iter=2000,
                                              class_weight="balanced"))])
logreg.fit(X_train, y_train)
pred_lr = logreg.predict(X_test)

print("Balanced logistic regression:")
print(confusion_matrix(y_test, pred_lr))
print("\n", classification_report(y_test, pred_lr, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC Recall on fraud jumps dramatically. Precision drops — we now raise more false
# MAGIC alarms. That trade-off *is* the fraud problem, and Module 8 makes it a dial.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 7 — The metrics that matter
# MAGIC
# MAGIC For imbalanced classification, judge models on:
# MAGIC
# MAGIC - **Confusion matrix** — the raw counts everything else is derived from.
# MAGIC - **Precision** = TP / (TP+FP): of the txns we flagged, how many were fraud.
# MAGIC - **Recall** = TP / (TP+FN): of the actual fraud, how much we caught.
# MAGIC - **F1** = harmonic mean of the two.
# MAGIC - **ROC-AUC** — ranking quality; optimistic under heavy imbalance.
# MAGIC - **PR-AUC (Average Precision)** — the honest headline metric here.
# MAGIC
# MAGIC We compute all of them and plot the two curves.

# COMMAND ----------

from sklearn.metrics import (precision_score, recall_score, f1_score,
                             roc_auc_score, average_precision_score,
                             roc_curve, precision_recall_curve,
                             ConfusionMatrixDisplay)

# Probabilities, not hard labels — needed for AUCs and threshold tuning
proba_lr = logreg.predict_proba(X_test)[:, 1]

def summary(y_true, y_pred, y_score, name):
    return {
        "model": name,
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall":    recall_score(y_true, y_pred),
        "f1":        f1_score(y_true, y_pred),
        "roc_auc":   roc_auc_score(y_true, y_score),
        "pr_auc":    average_precision_score(y_true, y_score),
    }

row_base = summary(y_test, pred_base, baseline.predict_proba(X_test)[:,1], "LogReg (no weighting)")
row_lr   = summary(y_test, pred_lr,   proba_lr, "LogReg (balanced)")
pd.DataFrame([row_base, row_lr]).set_index("model").round(3)

# COMMAND ----------

# Confusion matrix, ROC curve, PR curve side by side
fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))

ConfusionMatrixDisplay.from_predictions(y_test, pred_lr, ax=ax[0], colorbar=False)
ax[0].set_title("Confusion matrix (balanced LR)")

fpr, tpr, _ = roc_curve(y_test, proba_lr)
ax[1].plot(fpr, tpr, label=f"AUC={roc_auc_score(y_test, proba_lr):.3f}")
ax[1].plot([0, 1], [0, 1], "--", color="grey")
ax[1].set_xlabel("False Positive Rate"); ax[1].set_ylabel("True Positive Rate")
ax[1].set_title("ROC curve"); ax[1].legend()

prec, rec, _ = precision_recall_curve(y_test, proba_lr)
ax[2].plot(rec, prec, label=f"PR-AUC={average_precision_score(y_test, proba_lr):.3f}")
ax[2].axhline(y_test.mean(), ls="--", color="grey", label=f"baseline={y_test.mean():.3f}")
ax[2].set_xlabel("Recall"); ax[2].set_ylabel("Precision")
ax[2].set_title("Precision-Recall curve"); ax[2].legend()
plt.tight_layout(); plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Notice the ROC-AUC looks strong (~0.87) while PR-AUC is far lower. On a 2%-fraud
# MAGIC problem, ROC flatters the model. **PR-AUC is the number to quote to stakeholders.**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 8 — A stronger model & fair comparison
# MAGIC
# MAGIC Random forests capture the non-linear interactions in fraud (e.g. *foreign* AND
# MAGIC *large amount* AND *night*). We train one and compare on the honest metrics.

# COMMAND ----------

from sklearn.ensemble import RandomForestClassifier

rf = Pipeline([("prep", preprocess),
               ("clf", RandomForestClassifier(
                    n_estimators=300, max_depth=None, min_samples_leaf=2,
                    class_weight="balanced", random_state=7, n_jobs=-1))])
rf.fit(X_train, y_train)

proba_rf = rf.predict_proba(X_test)[:, 1]
pred_rf  = rf.predict(X_test)

row_rf = summary(y_test, pred_rf, proba_rf, "RandomForest (balanced)")
leaderboard = pd.DataFrame([row_base, row_lr, row_rf]).set_index("model").round(3)
leaderboard.sort_values("pr_auc", ascending=False)

# COMMAND ----------

# Overlay PR curves so the improvement is visual
fig, ax = plt.subplots(figsize=(7, 5))
for name, score in [("LogReg (balanced)", proba_lr), ("RandomForest", proba_rf)]:
    p, r, _ = precision_recall_curve(y_test, score)
    ax.plot(r, p, label=f"{name}  (AP={average_precision_score(y_test, score):.3f})")
ax.axhline(y_test.mean(), ls="--", color="grey", label=f"baseline={y_test.mean():.3f}")
ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
ax.set_title("Precision-Recall: model comparison"); ax.legend()
plt.tight_layout(); plt.show()

# COMMAND ----------

# Which features drive the forest? (post one-hot names)
ohe = rf.named_steps["prep"].named_transformers_["cat"]
feat_names = list(ohe.get_feature_names_out(categorical)) + numeric
importances = rf.named_steps["clf"].feature_importances_
imp = pd.Series(importances, index=feat_names).sort_values(ascending=False).head(12)
imp[::-1].plot(kind="barh", figsize=(8, 5), color="#4C72B0")
plt.title("Top feature importances (Random Forest)")
plt.tight_layout(); plt.show()
imp

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 9 — Threshold tuning & the cost of a decision
# MAGIC
# MAGIC A classifier outputs a probability; **you** choose the cut-off. The default 0.5
# MAGIC is almost never right for fraud. We tune the threshold two ways:
# MAGIC
# MAGIC 1. Maximise **F1**.
# MAGIC 2. Minimise **business cost**, given that a missed fraud (FN) and a false alarm
# MAGIC    (FP) don't cost the same.

# COMMAND ----------

import numpy as np

# 1) Threshold that maximises F1 on the RF scores
prec, rec, thr = precision_recall_curve(y_test, proba_rf)
# precision_recall_curve returns one more prec/rec point than thresholds
f1s = 2 * prec[:-1] * rec[:-1] / (prec[:-1] + rec[:-1] + 1e-9)
best_i = int(np.nanargmax(f1s))
best_thr_f1 = thr[best_i]
print(f"Best-F1 threshold: {best_thr_f1:.3f}  ->  "
      f"precision={prec[best_i]:.3f}, recall={rec[best_i]:.3f}, F1={f1s[best_i]:.3f}")

# COMMAND ----------

# 2) Cost-based threshold.
# Assume: a missed fraud costs the average fraud amount; a false alarm costs a
# fixed review/friction cost. Tune these with your client's real numbers.
COST_FN = float(data.loc[data.is_fraud == 1, "amount"].mean())  # ~ money lost
COST_FP = 8.0                                                   # review/friction $
print(f"Cost of a missed fraud (FN): ${COST_FN:,.2f}")
print(f"Cost of a false alarm (FP): ${COST_FP:,.2f}")

thresholds = np.linspace(0.01, 0.99, 99)
costs = []
for t in thresholds:
    pred = (proba_rf >= t).astype(int)
    fp = int(((pred == 1) & (y_test.values == 0)).sum())
    fn = int(((pred == 0) & (y_test.values == 1)).sum())
    costs.append(fp * COST_FP + fn * COST_FN)
costs = np.array(costs)
best_t = thresholds[int(costs.argmin())]
print(f"Cost-minimising threshold: {best_t:.2f}  (total cost ${costs.min():,.0f})")

# COMMAND ----------

fig, ax = plt.subplots(figsize=(8, 4.5))
ax.plot(thresholds, costs, color="#C44E52")
ax.axvline(best_t, ls="--", color="black", label=f"min-cost @ {best_t:.2f}")
ax.axvline(0.5, ls=":", color="grey", label="default 0.5")
ax.set_xlabel("decision threshold"); ax.set_ylabel("total business cost ($)")
ax.set_title("Choosing a threshold by business cost, not by default")
ax.legend(); plt.tight_layout(); plt.show()

# COMMAND ----------

# Apply the cost-optimal threshold and report the final operating point
final_pred = (proba_rf >= best_t).astype(int)
print(f"Operating threshold: {best_t:.2f}")
print(confusion_matrix(y_test, final_pred))
print("\n", classification_report(y_test, final_pred, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 10 — Track the experiment with MLflow
# MAGIC
# MAGIC On Databricks, MLflow is built in. Logging params, metrics, and the model makes
# MAGIC runs reproducible and comparable in the Experiments UI. This cell is a no-op
# MAGIC outside Databricks.

# COMMAND ----------

if ON_DATABRICKS:
    import mlflow, mlflow.sklearn
    with mlflow.start_run(run_name="rf_balanced_fraud"):
        mlflow.log_param("model", "RandomForestClassifier")
        mlflow.log_param("class_weight", "balanced")
        mlflow.log_param("threshold", round(float(best_t), 3))
        mlflow.log_metric("roc_auc", float(roc_auc_score(y_test, proba_rf)))
        mlflow.log_metric("pr_auc",  float(average_precision_score(y_test, proba_rf)))
        mlflow.log_metric("recall_at_threshold",
                          float(recall_score(y_test, final_pred)))
        mlflow.log_metric("precision_at_threshold",
                          float(precision_score(y_test, final_pred, zero_division=0)))
        mlflow.sklearn.log_model(rf, "model")
    print("Logged run to MLflow — open the Experiments panel to compare.")
else:
    print("MLflow logging skipped (not on Databricks).")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 11 — Wrap-up & challenge extensions
# MAGIC
# MAGIC **What we learned**
# MAGIC - Accuracy is meaningless for rare-event problems; PR-AUC and recall are honest.
# MAGIC - `class_weight="balanced"` recovers fraud recall the baseline threw away.
# MAGIC - Random forests beat linear models on the interaction-heavy fraud signal.
# MAGIC - The decision threshold is a business lever, not a default — tune it on cost.
# MAGIC - MLflow makes every run reproducible and comparable.
# MAGIC
# MAGIC **Challenge extensions (for fast finishers)**
# MAGIC 1. Swap the RF for gradient boosting (`HistGradientBoostingClassifier`) and
# MAGIC    compare PR-AUC.
# MAGIC 2. Try SMOTE oversampling (`imbalanced-learn`) instead of class weights.
# MAGIC 3. Add a `recall@precision>=0.5` metric and pick a threshold to hit it.
# MAGIC 4. Log all three models to MLflow and compare them in the Experiments UI.
# MAGIC 5. Persist the trained pipeline and score a fresh mini-batch of transactions.
