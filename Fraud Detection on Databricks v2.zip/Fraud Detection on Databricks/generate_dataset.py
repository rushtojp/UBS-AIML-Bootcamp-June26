"""
generate_dataset.py
-------------------------------------------------------------------
Synthetic credit-card transaction generator for the Aarvi Learning
Solutions "Fraud Detection on Databricks" lab.

Produces a realistically IMBALANCED dataset (~1.7% fraud) with signal
that a model can actually learn, while keeping every field explainable
to a classroom audience. No real customer data is used.

Run:  python generate_dataset.py
Out:  transactions.csv   (55,000 rows)
-------------------------------------------------------------------
"""

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)          # fixed seed => reproducible labs
N = 55_000
FRAUD_RATE = 0.017                        # ~1.7% positive class

MERCHANT_CATS = [
    "grocery", "restaurant", "fuel", "retail", "electronics",
    "travel", "entertainment", "utilities", "healthcare", "online_services",
]
# Categories that fraudsters disproportionately target
HIGH_RISK_CATS = {"electronics", "travel", "online_services"}

TXN_TYPES = ["chip", "swipe", "online", "contactless", "atm_withdrawal"]


def _base_frame(n):
    """Build the 'normal-behaviour' backbone of the dataset."""
    customer_id = RNG.integers(10_000, 19_999, size=n)
    customer_age = np.clip(RNG.normal(43, 14, size=n).round(), 18, 88).astype(int)
    account_tenure_days = RNG.integers(30, 4_000, size=n)

    # Genuine spend is small and right-skewed; log-normal is a good fit
    amount = np.round(RNG.lognormal(mean=3.4, sigma=0.9, size=n), 2)
    amount = np.clip(amount, 1.00, 4_000.00)

    hour = RNG.integers(0, 24, size=n)
    merchant_category = RNG.choice(MERCHANT_CATS, size=n)
    txn_type = RNG.choice(
        TXN_TYPES, size=n, p=[0.34, 0.16, 0.24, 0.20, 0.06]
    )

    card_present = np.where(
        np.isin(txn_type, ["chip", "swipe", "contactless", "atm_withdrawal"]), 1, 0
    )
    is_foreign = RNG.choice([0, 1], size=n, p=[0.93, 0.07])

    # Behavioural / velocity features (mostly benign)
    txns_last_24h = RNG.poisson(3, size=n)
    distance_from_home_km = np.round(np.abs(RNG.normal(12, 18, size=n)), 1)
    seconds_since_last_txn = RNG.integers(60, 172_800, size=n)  # up to 2 days

    df = pd.DataFrame(
        {
            "customer_id": customer_id,
            "customer_age": customer_age,
            "account_tenure_days": account_tenure_days,
            "amount": amount,
            "hour": hour,
            "merchant_category": merchant_category,
            "txn_type": txn_type,
            "card_present": card_present,
            "is_foreign": is_foreign,
            "txns_last_24h": txns_last_24h,
            "distance_from_home_km": distance_from_home_km,
            "seconds_since_last_txn": seconds_since_last_txn,
        }
    )
    return df


def _fraud_score(df):
    """
    A latent 'risk' score. Higher score => more likely to be flagged
    fraud. Encodes the domain rules we want learners to rediscover:
      - large amounts
      - card-not-present / online
      - foreign transactions
      - odd hours (late night)
      - high velocity (many txns in 24h, short gap)
      - far from home
      - high-risk merchant categories
    """
    s = np.zeros(len(df))
    s += (df["amount"] > 600) * 1.4
    s += (df["amount"] > 1500) * 1.6
    s += (df["card_present"] == 0) * 1.3
    s += (df["txn_type"] == "online") * 0.8
    s += (df["is_foreign"] == 1) * 1.5
    s += df["hour"].isin([0, 1, 2, 3, 4]) * 1.1
    s += (df["txns_last_24h"] >= 7) * 1.4
    s += (df["seconds_since_last_txn"] < 300) * 1.2
    s += (df["distance_from_home_km"] > 60) * 1.3
    s += df["merchant_category"].isin(HIGH_RISK_CATS) * 0.7
    s += (df["account_tenure_days"] < 120) * 0.6
    # small amount of noise so the boundary isn't perfectly separable
    s += RNG.normal(0, 0.8, size=len(df))
    return s


def generate():
    df = _base_frame(N)
    score = _fraud_score(df)

    # Choose a threshold on the score so that ~FRAUD_RATE rows are fraud
    cutoff = np.quantile(score, 1 - FRAUD_RATE)
    is_fraud = (score >= cutoff).astype(int)

    # Inject a little label noise (real labels are imperfect): flip 0.3%
    flip = RNG.random(len(df)) < 0.003
    is_fraud = np.where(flip, 1 - is_fraud, is_fraud)

    df["is_fraud"] = is_fraud

    # Build a readable transaction_id and timestamp last, for realism
    base = pd.Timestamp("2025-01-01")
    offsets = RNG.integers(0, 120 * 24 * 3600, size=len(df))
    df["timestamp"] = (base + pd.to_timedelta(offsets, unit="s")).astype(
        "datetime64[s]"
    )
    df.insert(0, "transaction_id", [f"T{100000 + i}" for i in range(len(df))])

    # Introduce a handful of realistic data-quality issues for the EDA module:
    #  - a few missing distances (sensor/geo lookup failed)
    miss_idx = RNG.choice(df.index, size=180, replace=False)
    df.loc[miss_idx, "distance_from_home_km"] = np.nan

    # Reorder columns for a clean CSV
    cols = [
        "transaction_id", "timestamp", "customer_id", "customer_age",
        "account_tenure_days", "amount", "merchant_category", "txn_type",
        "card_present", "is_foreign", "hour", "txns_last_24h",
        "distance_from_home_km", "seconds_since_last_txn", "is_fraud",
    ]
    df = df[cols].sort_values("timestamp").reset_index(drop=True)
    return df


if __name__ == "__main__":
    data = generate()
    data.to_csv("transactions.csv", index=False)
    n_fraud = int(data["is_fraud"].sum())
    print(f"Rows written      : {len(data):,}")
    print(f"Fraud rows        : {n_fraud:,}")
    print(f"Fraud rate        : {n_fraud / len(data):.3%}")
    print(f"Missing distances : {int(data['distance_from_home_km'].isna().sum())}")
    print("Saved -> transactions.csv")
