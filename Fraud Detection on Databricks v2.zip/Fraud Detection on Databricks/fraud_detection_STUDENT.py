# Databricks notebook source
# MAGIC %md
# MAGIC # Fraud Detection on Databricks — Student Workbook
# MAGIC
# MAGIC **Aarvi Learning Solutions | Machine Learning Lab**
# MAGIC
# MAGIC Work through the modules top to bottom. Cells marked **TODO** are yours to
# MAGIC complete — hints are in the comments. The instructor solution mirrors this
# MAGIC notebook module-for-module if you get stuck.
# MAGIC
# MAGIC **Runs on:** Databricks Free Edition / Community, or any single-node ML cluster.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 0 — Setup
# MAGIC
# MAGIC Upload `transactions.csv` (Lab Guide, Step 2), then set `DATA_PATH` below.

# COMMAND ----------

# TODO: set this to where you uploaded the CSV
#   Free Edition volume:  /Volumes/workspace/default/labdata/transactions.csv
#   FileStore:            /FileStore/tables/transactions.csv
DATA_PATH = "transactions.csv"

try:
    spark
    ON_DATABRICKS = True
except NameError:
    ON_DATABRICKS = False
print("On Databricks:", ON_DATABRICKS, "| path:", DATA_PATH)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 1 — Load the data
# MAGIC Read into Spark on Databricks, then a pandas copy for modelling.

# COMMAND ----------

import pandas as pd

if ON_DATABRICKS:
    sdf = spark.read.option("header", True).option("inferSchema", True).csv(DATA_PATH)
    pdf = sdf.toPandas()
else:
    pdf = pd.read_csv(DATA_PATH)

print("shape:", pdf.shape)
pdf.head()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 2 — Explore the class imbalance
# MAGIC **TODO:** compute how many rows are fraud vs legit, and the fraud rate.

# COMMAND ----------

# TODO: fill in the two lines below
counts = ...        # hint: value_counts() on the is_fraud column
rate   = ...        # hint: the mean of is_fraud is the fraud rate
print(counts)
print(f"Fraud rate: {rate:.3%}")

# COMMAND ----------

# Given: quick look at where fraud concentrates
def fraud_rate_by(col, top=10):
    g = (pdf.groupby(col)["is_fraud"].agg(["mean", "count"])
             .rename(columns={"mean": "fraud_rate", "count": "n"})
             .sort_values("fraud_rate", ascending=False))
    return g.head(top)

print(fraud_rate_by("txn_type"))
print(fraud_rate_by("card_present"))

# COMMAND ----------

# TODO: which columns have missing values? (hint: isna().sum())
missing = ...
print(missing[missing > 0])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 3 — Feature engineering
# MAGIC **TODO:** impute missing distance, then add the domain flags.

# COMMAND ----------

data = pdf.copy()

# TODO: fill missing distance_from_home_km with its median
median_dist = ...
data["distance_from_home_km"] = ...

# TODO: create these binary features (hint: .astype(int) on a boolean condition)
data["is_night"]      = ...   # hour in 0..5
data["high_velocity"] = ...   # txns_last_24h >= 7
data["large_amount"]  = ...   # amount > 600
# Given, to get you moving:
data["rapid_repeat"]  = (data["seconds_since_last_txn"] < 300).astype(int)
data["far_from_home"] = (data["distance_from_home_km"] > 60).astype(int)
data["amount_per_age"] = data["amount"] / data["customer_age"].clip(lower=18)
data.head()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 4 — Build the modelling matrix (given)
# MAGIC Stratified split so fraud appears in both train and test.

# COMMAND ----------

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

categorical = ["merchant_category", "txn_type"]
numeric = ["customer_age","account_tenure_days","amount","card_present","is_foreign",
           "hour","txns_last_24h","distance_from_home_km","seconds_since_last_txn",
           "is_night","high_velocity","rapid_repeat","large_amount","far_from_home",
           "amount_per_age"]

X = data[numeric + categorical]
y = data["is_fraud"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=7)

preprocess = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
    ("num", StandardScaler(), numeric)])
print("fraud in train/test:", int(y_train.sum()), int(y_test.sum()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 5 — Baseline & why accuracy lies (given)
# MAGIC Run this. Note the high accuracy but near-zero fraud recall.

# COMMAND ----------

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

baseline = Pipeline([("prep", preprocess), ("clf", LogisticRegression(max_iter=2000))])
baseline.fit(X_train, y_train)
pred_base = baseline.predict(X_test)
print("Accuracy:", round(accuracy_score(y_test, pred_base), 4))
print(confusion_matrix(y_test, pred_base))
print(classification_report(y_test, pred_base, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 6 — Handle the imbalance
# MAGIC **TODO:** train a logistic regression with `class_weight="balanced"`.

# COMMAND ----------

# TODO: build and fit a balanced logistic regression pipeline named `logreg`
logreg = ...
# logreg.fit(...)
pred_lr = logreg.predict(X_test)
print(confusion_matrix(y_test, pred_lr))
print(classification_report(y_test, pred_lr, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 7 — The metrics that matter
# MAGIC **TODO:** complete the metric summary. Use predicted **probabilities** for AUCs.

# COMMAND ----------

from sklearn.metrics import (precision_score, recall_score, f1_score,
                             roc_auc_score, average_precision_score,
                             precision_recall_curve, roc_curve, ConfusionMatrixDisplay)
import matplotlib.pyplot as plt

proba_lr = logreg.predict_proba(X_test)[:, 1]

def summary(y_true, y_pred, y_score, name):
    return {
        "model": name,
        "precision": ...,   # TODO
        "recall":    ...,   # TODO
        "f1":        f1_score(y_true, y_pred),
        "roc_auc":   roc_auc_score(y_true, y_score),
        "pr_auc":    ...,   # TODO: average_precision_score
    }

pd.DataFrame([summary(y_test, pred_lr, proba_lr, "LogReg (balanced)")]).round(3)

# COMMAND ----------

# TODO: plot the Precision-Recall curve for proba_lr
prec, rec, _ = precision_recall_curve(y_test, proba_lr)
plt.figure(figsize=(6,4))
plt.plot(rec, prec, label=f"PR-AUC={average_precision_score(y_test, proba_lr):.3f}")
plt.axhline(y_test.mean(), ls="--", color="grey", label="baseline")
plt.xlabel("Recall"); plt.ylabel("Precision"); plt.legend(); plt.title("PR curve")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 8 — A stronger model
# MAGIC **TODO:** train a balanced `RandomForestClassifier` and compare PR-AUC to the LR.

# COMMAND ----------

from sklearn.ensemble import RandomForestClassifier

# TODO: build/fit a balanced random forest pipeline named `rf`
rf = ...
# rf.fit(...)
proba_rf = rf.predict_proba(X_test)[:, 1]
pred_rf  = rf.predict(X_test)
print("RF PR-AUC:", round(average_precision_score(y_test, proba_rf), 3))
print("RF ROC-AUC:", round(roc_auc_score(y_test, proba_rf), 3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 9 — Threshold tuning & cost
# MAGIC **TODO:** find the decision threshold that minimises total business cost.

# COMMAND ----------

import numpy as np

COST_FN = float(data.loc[data.is_fraud == 1, "amount"].mean())  # money lost on a miss
COST_FP = 8.0                                                   # review cost of a false alarm

thresholds = np.linspace(0.01, 0.99, 99)
costs = []
for t in thresholds:
    pred = (proba_rf >= t).astype(int)
    fp = ...   # TODO: count false positives at this threshold
    fn = ...   # TODO: count false negatives at this threshold
    costs.append(fp * COST_FP + fn * COST_FN)

costs = np.array(costs)
best_t = thresholds[int(costs.argmin())]
print("Cost-minimising threshold:", round(best_t, 2))

plt.figure(figsize=(7,4))
plt.plot(thresholds, costs)
plt.axvline(best_t, ls="--", color="black", label=f"min-cost @ {best_t:.2f}")
plt.axvline(0.5, ls=":", color="grey", label="default 0.5")
plt.xlabel("threshold"); plt.ylabel("total cost ($)"); plt.legend(); plt.show()

# COMMAND ----------

# Given: report the final operating point at your chosen threshold
final_pred = (proba_rf >= best_t).astype(int)
print(confusion_matrix(y_test, final_pred))
print(classification_report(y_test, final_pred, digits=3))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 10 — Track with MLflow (given, Databricks only)

# COMMAND ----------

if ON_DATABRICKS:
    import mlflow, mlflow.sklearn
    with mlflow.start_run(run_name="student_rf_fraud"):
        mlflow.log_param("threshold", round(float(best_t), 3))
        mlflow.log_metric("pr_auc", float(average_precision_score(y_test, proba_rf)))
        mlflow.log_metric("roc_auc", float(roc_auc_score(y_test, proba_rf)))
        mlflow.sklearn.log_model(rf, "model")
    print("Run logged — open the Experiments panel.")
else:
    print("MLflow logging skipped (not on Databricks).")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Module 11 — Challenge extensions
# MAGIC 1. Try `HistGradientBoostingClassifier` and compare PR-AUC.
# MAGIC 2. Use SMOTE (`imbalanced-learn`) instead of class weights.
# MAGIC 3. Pick a threshold that guarantees precision >= 0.5, and report its recall.
# MAGIC 4. Log all your models to MLflow and compare in the Experiments UI.
