"""
Run this script once to generate all sample datasets for the lab.
  python generate_datasets.py
Requires: pandas, numpy
"""

import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)
DATA = Path("data")
DATA.mkdir(exist_ok=True)

TICKERS = ["AAPL", "MSFT", "JPM", "GS", "AMZN"]
COMPANIES = ["AlphaCorp", "BetaFin", "GammaTech", "DeltaBank", "EpsilonMfg",
             "ZetaHealth", "EtaEnergy", "ThetaRetail", "IotaMedia", "KappaAuto"]
START = pd.Timestamp("2023-01-02")
END   = pd.Timestamp("2023-12-29")
TRADING_DAYS = pd.bdate_range(START, END)

# ── Exercise 1: stock prices ──────────────────────────────────────────────────
base_prices = {"AAPL": 150, "MSFT": 240, "JPM": 130, "GS": 320, "AMZN": 90}
rows = []
for ticker, p0 in base_prices.items():
    prices = [p0]
    for _ in range(len(TRADING_DAYS) - 1):
        prices.append(prices[-1] * np.exp(np.random.normal(0.0003, 0.015)))
    rows.append(pd.DataFrame({
        "Date":   TRADING_DAYS,
        "Ticker": ticker,
        "Open":   [p * np.random.uniform(0.99, 1.005) for p in prices],
        "High":   [p * np.random.uniform(1.001, 1.02)  for p in prices],
        "Low":    [p * np.random.uniform(0.98, 0.999)  for p in prices],
        "Close":  prices,
        "Volume": np.random.randint(10_000_000, 80_000_000, len(TRADING_DAYS)),
    }))

prices_df = pd.concat(rows, ignore_index=True).round(2)
prices_df.to_csv(DATA / "stock_prices.csv", index=False)
print("[OK] stock_prices.csv")

# ── Exercise 2: messy income statement ───────────────────────────────────────
years = [2019, 2020, 2021, 2022, 2023]
revenue   = [4_200, 3_800, 5_100, 6_400, 7_200]   # $M
cogs      = [2_400, 2_300, 2_900, 3_600, 4_000]
sga       = [  620,   570,   720,   890,   980]
interest  = [   85,    90,    75,   100,   110]
tax_rate  = 0.21

messy = pd.DataFrame({
    "Fiscal Year": [str(y) for y in years],
    " Revenue ($M) ": [f"${v:,}M" for v in revenue],
    "Cost of Goods Sold": [f"${v:,}" for v in cogs],
    "SG&A Expenses": [f"  ${v}M  " for v in sga],
    "Interest Expense": [f"${v}" if i != 2 else None for i, v in enumerate(interest)],
    "Net Income": [round((r - c - s - e) * (1 - tax_rate), 1)
                   if e else None
                   for r, c, s, e in zip(revenue, cogs, sga, interest)],
})
messy.to_csv(DATA / "income_statement.csv", index=False)
print("[OK] income_statement.csv")

# ── Exercise 3: portfolio holdings ───────────────────────────────────────────
purchase_prices = {"AAPL": 138.0, "MSFT": 220.5, "JPM": 118.0, "GS": 298.0, "AMZN": 82.5}
holdings = pd.DataFrame({
    "Ticker":         TICKERS,
    "Shares":         [150, 80, 200, 30, 120],
    "Purchase_Price": [purchase_prices[t] for t in TICKERS],
    "Purchase_Date":  ["2022-03-15", "2022-06-01", "2022-01-10", "2021-11-20", "2022-09-05"],
})
holdings.to_csv(DATA / "portfolio_holdings.csv", index=False)
print("[OK] portfolio_holdings.csv")
# prices_df already saved — students merge on their own

# ── Exercise 4: uses stock_prices.csv — no extra file needed ─────────────────
# Market index (S&P 500 proxy) for benchmark
sp500 = [4_000]
for _ in range(len(TRADING_DAYS) - 1):
    sp500.append(sp500[-1] * np.exp(np.random.normal(0.0002, 0.010)))
mkt = pd.DataFrame({"Date": TRADING_DAYS, "SPX_Close": [round(p, 2) for p in sp500]})
mkt.to_csv(DATA / "sp500_index.csv", index=False)
print("[OK] sp500_index.csv")

# ── Exercise 5: wide quarterly financials ─────────────────────────────────────
quarters = pd.period_range("2019Q1", "2023Q4", freq="Q")
records = []
for co in COMPANIES:
    rev_base = np.random.uniform(500, 5000)
    eq_base  = np.random.uniform(1000, 8000)
    for q in quarters:
        trend  = 1 + np.random.uniform(-0.02, 0.05)
        rev    = round(rev_base * trend + np.random.normal(0, 50), 1)
        cogs_q = round(rev * np.random.uniform(0.45, 0.65), 1)
        ni     = round((rev - cogs_q) * np.random.uniform(0.08, 0.22), 1)
        equity = round(eq_base + np.random.normal(0, 200), 1)
        debt   = round(eq_base * np.random.uniform(0.3, 1.2), 1)
        curr_a = round(rev * np.random.uniform(0.4, 0.8), 1)
        curr_l = round(curr_a * np.random.uniform(0.5, 0.9), 1)
        price  = round(np.random.uniform(20, 500), 2)
        eps    = round(ni / np.random.uniform(50, 300), 2)
        records.append({
            "Company":          co,
            "Quarter":          str(q),
            "Revenue":          rev,
            "COGS":             cogs_q,
            "Net_Income":       ni,
            "Total_Equity":     equity,
            "Total_Debt":       debt,
            "Current_Assets":   curr_a,
            "Current_Liabilities": curr_l,
            "Stock_Price":      price,
            "EPS":              eps,
        })
        rev_base = rev
        eq_base  = equity

wide_df = pd.DataFrame(records)
wide_df.to_csv(DATA / "quarterly_financials.csv", index=False)
print("[OK] quarterly_financials.csv")

# ── Exercise 6: earnings calendar + prices ────────────────────────────────────
# Earnings dates: one per quarter per ticker
earn_rows = []
for ticker in TICKERS:
    for qstart in ["2023-01-25", "2023-04-26", "2023-07-26", "2023-10-25"]:
        date = pd.Timestamp(qstart) + pd.Timedelta(days=np.random.randint(-2, 3))
        date = date if date.weekday() < 5 else date + pd.Timedelta(days=1)
        eps_est    = round(np.random.uniform(1.0, 5.0), 2)
        eps_actual = round(eps_est * np.random.uniform(0.85, 1.20), 2)
        earn_rows.append({
            "Ticker":     ticker,
            "Ann_Date":   date.strftime("%Y-%m-%d"),
            "EPS_Est":    eps_est,
            "EPS_Actual": eps_actual,
            "Surprise_Pct": round((eps_actual - eps_est) / abs(eps_est) * 100, 2),
        })

earnings_df = pd.DataFrame(earn_rows)
earnings_df.to_csv(DATA / "earnings_calendar.csv", index=False)
print("[OK] earnings_calendar.csv")

print("\nAll datasets generated in ./data/"  )
