"""
Exercise 5 — Building a multi-company financial ratio dashboard
MBA Finance: Python for Data Wrangling | Level: Advanced

CONTEXT
-------
Credit analysts and equity researchers regularly compare financial ratios
across a peer group to spot outliers. The raw data often arrives in "wide"
format (one column per metric per quarter). Your job is to reshape it into
a tidy long format, derive the standard ratios, detect deteriorating
companies, and produce a clean pivot table summary — the kind of output
that would go into an analyst report.

LEARNING OBJECTIVES
-------------------
- Reshape wide → long with melt()
- Pivot back to a computation-friendly format with pivot_table()
- Compute and interpret four standard financial ratios
- Detect year-over-year change with pct_change(4)
- Style a pandas DataFrame for presentation

DATA FILE
---------
  data/quarterly_financials.csv
  Columns: Company, Quarter, Revenue, COGS, Net_Income, Total_Equity,
           Total_Debt, Current_Assets, Current_Liabilities,
           Stock_Price, EPS
"""

import pandas as pd

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load quarterly_financials.csv.
# Melt all metric columns into long format:
#   id_vars  = ['Company', 'Quarter']
#   var_name = 'Metric'
#   value_name = 'Value'
#
# Print the shape and first 10 rows of the long DataFrame.

df_wide = None  # replace
df_long = None  # replace


# ── Task 2 ────────────────────────────────────────────────────────────────────
# Pivot df_long back so that each row is one (Company, Quarter) observation
# and each column is a metric.
#
# Hint: pivot_table(index=['Company','Quarter'], columns='Metric', values='Value')
# Reset the index and flatten the MultiIndex columns.

ratios = None  # replace


# ── Task 3 ────────────────────────────────────────────────────────────────────
# Compute four standard ratios and add them as columns:
#
#   P/E ratio        = Stock_Price / EPS                 (valuation)
#   Debt/Equity      = Total_Debt / Total_Equity         (leverage)
#   Current Ratio    = Current_Assets / Current_Liabilities  (liquidity)
#   ROE              = Net_Income / Total_Equity × 4     (annualized, profitability)
#
# Handle divide-by-zero or negative equity gracefully with .replace() or clip.



# ── Task 4 ────────────────────────────────────────────────────────────────────
# For each company, compute year-over-year change in ROE using pct_change(4)
# (4 quarters = one year).
# Flag any company-quarter where ROE deteriorated by more than 20% YoY.
# Print the flagged rows.
#
# Hint: sort by Company then Quarter before calling pct_change



# ── Task 5 ────────────────────────────────────────────────────────────────────
# Build a summary pivot table showing the LATEST quarter's ratios for all
# companies. Rows = companies, columns = the four ratios.
# Sort by ROE descending.
# Apply pandas Styler to highlight the top quartile green, bottom quartile red.



# ── Bonus ─────────────────────────────────────────────────────────────────────
# Which company has the most consistently high Current Ratio across all quarters?
# Use rolling(4).mean() to smooth and rank.
