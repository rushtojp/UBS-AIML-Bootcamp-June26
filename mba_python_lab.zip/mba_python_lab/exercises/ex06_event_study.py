"""
Exercise 6 — Event study: earnings surprise and abnormal returns
MBA Finance: Python for Data Wrangling | Level: Advanced

CONTEXT
-------
An event study measures whether a specific corporate event (earnings
announcement, M&A deal, dividend cut) causes abnormal stock returns. The
standard design: define an event window [t-5, t+5] trading days around the
announcement, compute cumulative abnormal return (CAR) — return in excess of
the market benchmark — and test whether beats vs. misses drive different CARs.

This is a real empirical finance method used in academic research and by
sell-side analysts to quantify market reaction to news.

LEARNING OBJECTIVES
-------------------
- Align two time-series datasets on a non-exact date key
- Extract index-based row windows from a DataFrame
- Compute cumulative abnormal returns
- Group by a categorical variable (beat / meet / miss)
- Run a one-sample t-test to test statistical significance

DATA FILES
----------
  data/earnings_calendar.csv
    Columns: Ticker, Ann_Date, EPS_Est, EPS_Actual, Surprise_Pct

  data/stock_prices.csv
    Columns: Date, Ticker, Open, High, Low, Close, Volume

  data/sp500_index.csv
    Columns: Date, SPX_Close
"""

import numpy as np
import pandas as pd
from scipy import stats

WINDOW = 5   # trading days before/after the announcement

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load all three files. Parse date columns.
# Compute daily log returns for each stock: log_ret = ln(Close_t / Close_{t-1})
# Compute daily SPX log returns from SPX_Close.

events = None  # replace
prices = None  # replace
mkt    = None  # replace


# ── Task 2 ────────────────────────────────────────────────────────────────────
# For each row in events, find the trading day index of Ann_Date in the
# prices table for that ticker.
# If the exact date is not a trading day (weekend / holiday), use the next
# available trading day.
#
# Hint: merge_asof with direction='forward' works well here, or
#       searchsorted on a sorted date array.



# ── Task 3 ────────────────────────────────────────────────────────────────────
# Write a function get_car(ticker, ann_date, prices, mkt, window=5) that:
#   1. Slices prices to the [ann_date - window, ann_date + window] window
#   2. Merges with mkt returns on Date
#   3. Computes abnormal_ret = log_ret − spx_log_ret for each day
#   4. Returns the sum of abnormal_ret (= CAR) over the window
#
# Apply it to every row in events and store the result in a new column 'CAR'.

def get_car(ticker, ann_date, prices, mkt, window=WINDOW):
    pass   # replace with your implementation

events['CAR'] = None  # replace


# ── Task 4 ────────────────────────────────────────────────────────────────────
# Classify each event into:
#   'Beat'  if Surprise_Pct > +2%
#   'Miss'  if Surprise_Pct < -2%
#   'Meet'  otherwise
#
# Compute the mean CAR for each group. Does the pattern match your expectations?



# ── Task 5 ────────────────────────────────────────────────────────────────────
# For the 'Beat' group, run a one-sample t-test to determine whether the
# mean CAR is statistically different from 0 (i.e., is the positive reaction
# significant?).
#
# Report: t-statistic, p-value, and your conclusion at the 5% level.
#
# Hint: scipy.stats.ttest_1samp(beat_cars, popmean=0)



# ── Bonus ─────────────────────────────────────────────────────────────────────
# Plot the average cumulative return day-by-day (not just total CAR) for Beat
# vs. Miss groups — the classic "event study graph" showing the reaction path.
# Day 0 = announcement day.
