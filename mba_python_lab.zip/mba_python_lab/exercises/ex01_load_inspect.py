"""
Exercise 1 — Loading and inspecting a stock price dataset
MBA Finance: Python for Data Wrangling | Level: Beginner

CONTEXT
-------
You have just received a CSV file of daily OHLCV (Open, High, Low, Close,
Volume) prices for five S&P 500 stocks across the full calendar year 2023.
Before building any model or chart, a finance analyst must understand the
data's structure, quality, and basic statistics.

LEARNING OBJECTIVES
-------------------
- Load a CSV with proper date parsing
- Inspect shape, dtypes, and missing values
- Use groupby + aggregation for summary statistics
- Filter and locate specific rows

DATA FILE
---------
  data/stock_prices.csv
  Columns: Date, Ticker, Open, High, Low, Close, Volume
"""

import pandas as pd

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load data/stock_prices.csv. Make sure the Date column is parsed as a
# datetime, not a plain string.
#
# Hint: use the parse_dates parameter of pd.read_csv()

df = None  # replace with your code


# ── Task 2 ────────────────────────────────────────────────────────────────────
# Print the shape of the DataFrame and the data type of each column.
# Then count missing values per column.



# ── Task 3 ────────────────────────────────────────────────────────────────────
# For each Ticker, compute the mean, minimum, and maximum closing price
# across all trading days in 2023.



# ── Task 4 ────────────────────────────────────────────────────────────────────
# Which ticker recorded the single highest closing price on any day?
# Print the full row (Date, Ticker, Close).



# ── Bonus ─────────────────────────────────────────────────────────────────────
# How many trading days are in the dataset per ticker?
# Are all tickers present for exactly the same set of dates?
