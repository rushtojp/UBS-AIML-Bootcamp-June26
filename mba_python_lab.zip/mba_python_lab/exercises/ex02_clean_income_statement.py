"""
Exercise 2 — Cleaning a messy income statement
MBA Finance: Python for Data Wrangling | Level: Beginner

CONTEXT
-------
A junior analyst scraped five years of income statement data from a company's
investor relations page. The resulting CSV has inconsistent formatting:
currency symbols, trailing "M" labels, extra whitespace in column names,
and a missing value in one row. You need to clean it before computing ratios.

LEARNING OBJECTIVES
-------------------
- Strip and parse mixed-format numeric strings
- Rename columns to snake_case
- Handle missing values intentionally (drop vs. fill)
- Derive a standard financial ratio from cleaned data

DATA FILE
---------
  data/income_statement.csv
  Columns (raw): Fiscal Year, Revenue ($M), Cost of Goods Sold,
                 SG&A Expenses, Interest Expense, Net Income
"""

import pandas as pd

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load data/income_statement.csv. Print the raw column names and the first
# few rows so you can see what needs cleaning.

df = None  # replace with your code


# ── Task 2 ────────────────────────────────────────────────────────────────────
# Standardize column names:
#   - Strip leading/trailing whitespace
#   - Convert to lowercase
#   - Replace spaces and special characters with underscores
#
# Expected result: fiscal_year, revenue_m, cost_of_goods_sold,
#                  sga_expenses, interest_expense, net_income



# ── Task 3 ────────────────────────────────────────────────────────────────────
# The revenue column contains strings like "$4,200M". Clean ALL numeric
# columns so they hold Python floats (units: millions of dollars).
#
# Hint: str.replace() with regex=True, then .astype(float)



# ── Task 4 ────────────────────────────────────────────────────────────────────
# One row has a missing Interest Expense value. Inspect it, then decide:
#   a) Drop the row (use dropna with subset=)  — OR —
#   b) Fill it with the column median (use fillna)
# Justify your choice in a comment.



# ── Task 5 ────────────────────────────────────────────────────────────────────
# Compute the following ratios and add them as new columns:
#   gross_margin  = (revenue - cogs) / revenue        — expressed as %
#   ebit          = revenue - cogs - sga
#   interest_coverage = ebit / interest_expense
# Print the final table.



# ── Bonus ─────────────────────────────────────────────────────────────────────
# In which year was the gross margin highest? Lowest?
# Is the interest coverage ratio improving or deteriorating over time?
