"""
Exercise 3 — Merging portfolio holdings with price data
MBA Finance: Python for Data Wrangling | Level: Intermediate

CONTEXT
-------
You manage a small equity portfolio. One table lists your holdings (ticker,
number of shares, and purchase price). Another table has daily closing prices
for the same tickers. You need to join them to compute your current portfolio
value and unrealized profit/loss — the basic output of any portfolio management
system.

LEARNING OBJECTIVES
-------------------
- Filter a DataFrame to a specific condition (latest date)
- Merge two DataFrames on a key column
- Compute derived columns with assign() or direct arithmetic
- Aggregate to a portfolio-level summary

DATA FILES
----------
  data/portfolio_holdings.csv
    Columns: Ticker, Shares, Purchase_Price, Purchase_Date

  data/stock_prices.csv
    Columns: Date, Ticker, Open, High, Low, Close, Volume
"""

import pandas as pd

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load both CSV files. Parse Date columns as datetime where appropriate.

holdings = None  # replace
prices   = None  # replace


# ── Task 2 ────────────────────────────────────────────────────────────────────
# From the prices DataFrame, keep only the rows where Date equals the most
# recent available date (do NOT hardcode "2023-12-29").
#
# Hint: prices['Date'].max()

latest_prices = None  # replace


# ── Task 3 ────────────────────────────────────────────────────────────────────
# Left-join holdings onto latest_prices on the Ticker column.
# After the merge, confirm every holding has a matched price (no NaN in Close).

portfolio = None  # replace


# ── Task 4 ────────────────────────────────────────────────────────────────────
# Add three columns to portfolio:
#   market_value     = Shares × Close
#   cost_basis       = Shares × Purchase_Price
#   unrealized_pnl   = market_value − cost_basis
#   pnl_pct          = unrealized_pnl / cost_basis × 100



# ── Task 5 ────────────────────────────────────────────────────────────────────
# Print a summary showing:
#   - Total portfolio market value
#   - Total unrealized P&L ($)
#   - Total portfolio return (%)
#   - The single best and worst performing position by pnl_pct



# ── Bonus ─────────────────────────────────────────────────────────────────────
# Add a column weight_pct = each position's market value as % of total.
# Which single stock dominates the portfolio by weight?
