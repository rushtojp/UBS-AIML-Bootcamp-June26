"""
Exercise 4 — Computing rolling returns and volatility
MBA Finance: Python for Data Wrangling | Level: Intermediate

CONTEXT
-------
Volatility is the foundation of risk measurement, options pricing (Black-
Scholes), and portfolio construction (Markowitz). A 30-day rolling realized
volatility—computed from daily log returns and annualized—is one of the most
common outputs a quant analyst must produce from raw price data.

LEARNING OBJECTIVES
-------------------
- Compute log returns with shift() and numpy
- Apply rolling window statistics per group with groupby + transform
- Annualize volatility using the sqrt-of-time rule
- Resample time-series data to a lower frequency

DATA FILES
----------
  data/stock_prices.csv    — daily OHLCV for 5 tickers
  data/sp500_index.csv     — daily S&P 500 index level (column: SPX_Close)
"""

import numpy as np
import pandas as pd

# ── Task 1 ────────────────────────────────────────────────────────────────────
# Load stock_prices.csv (parse Date). Sort by Ticker then Date.
# Compute the daily log return for each ticker:
#     log_ret = ln(Close_t / Close_{t-1})
#
# Use groupby + shift so returns don't bleed across tickers.

df = None  # replace


# ── Task 2 ────────────────────────────────────────────────────────────────────
# Compute a 30-trading-day rolling standard deviation of log_ret per ticker.
# Annualize it by multiplying by sqrt(252).
# Store the result in a column named vol_30d.
# Drop rows where vol_30d is NaN (first 29 rows per ticker).
#
# Hint: use groupby + transform with a lambda, or sort and use rolling directly



# ── Task 3 ────────────────────────────────────────────────────────────────────
# Find the 5 date-ticker combinations with the highest 30-day rolling vol.
# Print Date, Ticker, and vol_30d. Do they cluster around a specific event?



# ── Task 4 ────────────────────────────────────────────────────────────────────
# Resample to monthly frequency: for each ticker, compute the average vol_30d
# in each calendar month.
#
# Hint: set Date as index, groupby Ticker, then resample('ME').mean()
# Expected shape: (n_months × n_tickers) rows, with columns ticker and vol_30d



# ── Task 5 ────────────────────────────────────────────────────────────────────
# Load sp500_index.csv. Compute SPX log returns.
# For each stock, compute the CORRELATION between its daily log_ret and the
# SPX log_ret over the full year.
# Which stock has the highest beta-like correlation with the market?



# ── Bonus ─────────────────────────────────────────────────────────────────────
# Plot (with matplotlib or plotly) the rolling vol for all 5 tickers on one
# chart. Add a horizontal line at 20% (typical VIX baseline).
