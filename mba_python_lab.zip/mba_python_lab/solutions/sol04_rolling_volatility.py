"""Solution — Exercise 4: Computing rolling returns and volatility"""

import numpy as np
import pandas as pd

# Task 1
df = pd.read_csv("data/stock_prices.csv", parse_dates=["Date"])
df.sort_values(["Ticker", "Date"], inplace=True)
df["log_ret"] = df.groupby("Ticker")["Close"].transform(
    lambda x: np.log(x / x.shift(1))
)

# Task 2
df["vol_30d"] = df.groupby("Ticker")["log_ret"].transform(
    lambda x: x.rolling(30).std() * np.sqrt(252)
)
df.dropna(subset=["vol_30d"], inplace=True)

# Task 3
top5 = df.nlargest(5, "vol_30d")[["Date", "Ticker", "vol_30d"]].round(4)
print("Top 5 highest vol windows:\n", top5)

# Task 4
monthly_vol = (df.set_index("Date")
               .groupby("Ticker")["vol_30d"]
               .resample("ME")
               .mean()
               .round(4))
print("\nMonthly average vol:\n", monthly_vol)

# Task 5
mkt = pd.read_csv("data/sp500_index.csv", parse_dates=["Date"])
mkt.sort_values("Date", inplace=True)
mkt["spx_ret"] = np.log(mkt["SPX_Close"] / mkt["SPX_Close"].shift(1))
df = df.merge(mkt[["Date", "spx_ret"]], on="Date", how="left")

corr = df.groupby("Ticker").apply(
    lambda g: g[["log_ret", "spx_ret"]].corr().iloc[0, 1]
).round(4)
print("\nCorrelation with S&P 500:\n", corr.sort_values(ascending=False))
