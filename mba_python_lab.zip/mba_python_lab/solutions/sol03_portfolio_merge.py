"""Solution — Exercise 3: Merging portfolio holdings with price data"""

import pandas as pd

# Task 1
holdings = pd.read_csv("data/portfolio_holdings.csv", parse_dates=["Purchase_Date"])
prices   = pd.read_csv("data/stock_prices.csv", parse_dates=["Date"])

# Task 2
latest_prices = prices[prices["Date"] == prices["Date"].max()].copy()

# Task 3
portfolio = holdings.merge(latest_prices[["Ticker", "Date", "Close"]],
                           on="Ticker", how="left")
assert portfolio["Close"].notna().all(), "Some tickers have no price match"

# Task 4
portfolio["market_value"]   = portfolio["Shares"] * portfolio["Close"]
portfolio["cost_basis"]     = portfolio["Shares"] * portfolio["Purchase_Price"]
portfolio["unrealized_pnl"] = portfolio["market_value"] - portfolio["cost_basis"]
portfolio["pnl_pct"]        = (portfolio["unrealized_pnl"] / portfolio["cost_basis"] * 100).round(2)

# Task 5
total_mkt  = portfolio["market_value"].sum()
total_pnl  = portfolio["unrealized_pnl"].sum()
total_cost = portfolio["cost_basis"].sum()
total_ret  = total_pnl / total_cost * 100

print(f"Total market value : ${total_mkt:,.2f}")
print(f"Total unrealized P&L: ${total_pnl:,.2f}")
print(f"Total portfolio return: {total_ret:.2f}%")
print("\nBest position:\n",  portfolio.loc[portfolio["pnl_pct"].idxmax()])
print("\nWorst position:\n", portfolio.loc[portfolio["pnl_pct"].idxmin()])

# Bonus
portfolio["weight_pct"] = (portfolio["market_value"] / total_mkt * 100).round(2)
print("\nPortfolio weights:\n", portfolio[["Ticker","weight_pct"]].sort_values("weight_pct", ascending=False))
