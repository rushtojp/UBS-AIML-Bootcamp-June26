"""Solution — Exercise 5: Multi-company financial ratio dashboard"""

import pandas as pd

# Task 1
df_wide = pd.read_csv("data/quarterly_financials.csv")
df_long = df_wide.melt(id_vars=["Company", "Quarter"],
                       var_name="Metric", value_name="Value")
print("Long shape:", df_long.shape)
print(df_long.head(10))

# Task 2
ratios = df_long.pivot_table(index=["Company", "Quarter"],
                             columns="Metric",
                             values="Value").reset_index()
ratios.columns.name = None

# Task 3
ratios["PE_Ratio"]     = (ratios["Stock_Price"] / ratios["EPS"].replace(0, pd.NA)).round(2)
ratios["Debt_Equity"]  = (ratios["Total_Debt"]  / ratios["Total_Equity"].replace(0, pd.NA)).round(2)
ratios["Current_Ratio"]= (ratios["Current_Assets"] / ratios["Current_Liabilities"].replace(0, pd.NA)).round(2)
ratios["ROE"]          = (ratios["Net_Income"] / ratios["Total_Equity"].replace(0, pd.NA) * 4).round(4)

# Task 4
ratios.sort_values(["Company", "Quarter"], inplace=True)
ratios["ROE_YoY"] = ratios.groupby("Company")["ROE"].pct_change(4)
flagged = ratios[ratios["ROE_YoY"] < -0.20][["Company","Quarter","ROE","ROE_YoY"]]
print("\nCompanies with >20% YoY ROE deterioration:\n", flagged)

# Task 5
latest_q = ratios["Quarter"].max()
summary  = (ratios[ratios["Quarter"] == latest_q]
            .set_index("Company")[["PE_Ratio","Debt_Equity","Current_Ratio","ROE"]]
            .sort_values("ROE", ascending=False))

def color_quartile(s):
    q25, q75 = s.quantile(0.25), s.quantile(0.75)
    return ["background-color: #d4edda" if v >= q75
            else "background-color: #f8d7da" if v <= q25
            else "" for v in s]

styled = summary.style.apply(color_quartile)
print("\nLatest quarter ratio summary:\n", summary)
# styled.to_excel("ratio_dashboard.xlsx", engine="openpyxl")  # uncomment to export
