"""Solution — Exercise 1: Loading and inspecting a stock price dataset"""

import pandas as pd

# Task 1
df = pd.read_csv("data/stock_prices.csv", parse_dates=["Date"])

# Task 2
print("Shape:", df.shape)
print("\nDtypes:\n", df.dtypes)
print("\nMissing values:\n", df.isnull().sum())

# Task 3
summary = df.groupby("Ticker")["Close"].agg(["mean", "min", "max"]).round(2)
print("\nClose price stats by ticker:\n", summary)

# Task 4
idx_max = df["Close"].idxmax()
print("\nHighest single-day close:\n", df.loc[idx_max, ["Date", "Ticker", "Close"]])

# Bonus
counts = df.groupby("Ticker")["Date"].count()
print("\nTrading days per ticker:\n", counts)
all_same = counts.nunique() == 1
print("All tickers have identical trading days:", all_same)
