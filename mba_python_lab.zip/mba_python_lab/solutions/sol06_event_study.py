"""Solution — Exercise 6: Event study — earnings surprise and abnormal returns"""

import numpy as np
import pandas as pd
from scipy import stats

WINDOW = 5

# Task 1
events = pd.read_csv("data/earnings_calendar.csv", parse_dates=["Ann_Date"])
prices = pd.read_csv("data/stock_prices.csv",      parse_dates=["Date"])
mkt    = pd.read_csv("data/sp500_index.csv",       parse_dates=["Date"])

prices.sort_values(["Ticker", "Date"], inplace=True)
prices["log_ret"] = prices.groupby("Ticker")["Close"].transform(
    lambda x: np.log(x / x.shift(1))
)

mkt.sort_values("Date", inplace=True)
mkt["spx_ret"] = np.log(mkt["SPX_Close"] / mkt["SPX_Close"].shift(1))

# Task 2 — forward-fill announcement date to nearest trading day
trading_days = prices["Date"].drop_duplicates().sort_values().reset_index(drop=True)

def nearest_trading_day(date):
    idx = trading_days.searchsorted(date)
    idx = min(idx, len(trading_days) - 1)
    return trading_days.iloc[idx]

events["Trade_Date"] = events["Ann_Date"].apply(nearest_trading_day)

# Task 3
def get_car(row, prices, mkt, window=WINDOW):
    tk_prices = prices[prices["Ticker"] == row["Ticker"]].sort_values("Date").reset_index(drop=True)
    match = tk_prices[tk_prices["Date"] == row["Trade_Date"]]
    if match.empty:
        return np.nan
    center = match.index[0]
    start  = max(0, center - window)
    end    = min(len(tk_prices) - 1, center + window)
    w      = tk_prices.loc[start:end].merge(mkt[["Date","spx_ret"]], on="Date", how="inner")
    w["abn_ret"] = w["log_ret"] - w["spx_ret"]
    return w["abn_ret"].sum()

events["CAR"] = events.apply(get_car, axis=1, prices=prices, mkt=mkt)

# Task 4
def classify(pct):
    if pct > 2:   return "Beat"
    if pct < -2:  return "Miss"
    return "Meet"

events["Group"] = events["Surprise_Pct"].apply(classify)
group_means = events.groupby("Group")["CAR"].mean().round(4)
print("Mean CAR by earnings surprise group:\n", group_means)

# Task 5
beat_cars = events.loc[events["Group"] == "Beat", "CAR"].dropna()
t_stat, p_val = stats.ttest_1samp(beat_cars, popmean=0)
print(f"\nt-test (Beat group CAR ≠ 0):")
print(f"  t-statistic : {t_stat:.4f}")
print(f"  p-value     : {p_val:.4f}")
print(f"  Significant at 5%: {p_val < 0.05}")
