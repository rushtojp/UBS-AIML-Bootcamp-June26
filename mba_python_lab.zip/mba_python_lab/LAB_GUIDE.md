# Python for Finance: Data Wrangling Lab
### MBA Finance Program — Hands-On Workshop

---

## Overview

This lab builds practical Python skills for financial data analysis. Each exercise uses a realistic finance scenario and real-world messy data. Students work through six exercises that progress from loading a CSV to running an event study used in academic research and sell-side analysis.

**Duration:** 3–4 hours (full lab) or 45–60 min per exercise pair  
**Level:** No prior Python required for Ex 1–2; basic Python for Ex 3–4; comfort with pandas for Ex 5–6  
**Prerequisites:** Python 3.9+, pandas, numpy, scipy installed  

---

## Setup (5 minutes)

**Step 1 — Install dependencies**

```bash
pip install pandas numpy scipy matplotlib
```

**Step 2 — Generate datasets**

```bash
cd mba_python_lab
python generate_datasets.py
```

You should see six CSV files created in the `data/` folder.

**Step 3 — Open your first exercise**

```bash
# Work in the exercises/ folder
# Solutions are in solutions/ — don't peek until you've tried!
```

---

## Lab Structure

| Exercise | Title | Level | Key Skills | Data File(s) |
|---|---|---|---|---|
| 1 | Loading & inspecting stock prices | Beginner | read_csv, groupby, describe | stock_prices.csv |
| 2 | Cleaning a messy income statement | Beginner | str.replace, rename, dropna | income_statement.csv |
| 3 | Merging portfolio holdings with prices | Intermediate | merge, assign, aggregation | holdings + prices |
| 4 | Rolling returns and volatility | Intermediate | shift, rolling, resample | prices + sp500 |
| 5 | Multi-company ratio dashboard | Advanced | melt, pivot_table, pct_change | quarterly_financials.csv |
| 6 | Earnings surprise event study | Advanced | merge_asof, apply, ttest | earnings + prices + sp500 |

---

## Exercise 1 — Loading and Inspecting a Stock Price Dataset

### Scenario

You receive a CSV of daily prices for five S&P 500 stocks (AAPL, MSFT, JPM, GS, AMZN) for the full year 2023. Before any analysis, understand what you have.

### Tasks

1. Load `data/stock_prices.csv`, parsing the Date column as a datetime.
2. Print shape, column dtypes, and count of missing values.
3. Compute mean, min, and max closing price per ticker using `groupby`.
4. Find the single row with the highest closing price across all tickers and dates.
5. **Bonus:** Confirm all tickers have the same number of trading days.

### Expected output (approximate)

```
Shape: (1255, 7)
No missing values

       mean    min     max
AAPL  172.3  132.1   198.2
...

Highest single-day close: GS, 2023-11-08, $389.xx
```

### Discussion questions

- Why parse dates rather than leaving them as strings?
- What would `idxmax()` return if two rows tied for the maximum?
- When would you use `describe()` vs. writing your own aggregation?

---

## Exercise 2 — Cleaning a Messy Income Statement

### Scenario

A junior analyst scraped five years of income statements from an investor relations page. The CSV has currency symbols, trailing "M" labels, extra whitespace in column names, and one missing value in Interest Expense.

### Tasks

1. Load the raw CSV and inspect the column names and first few rows.
2. Standardize column names to `snake_case` with no special characters.
3. Strip `$`, `,`, `M` from all numeric columns and cast to float.
4. Handle the missing Interest Expense — fill with median rather than dropping the row.
5. Compute gross margin %, EBIT, and interest coverage ratio.
6. **Bonus:** In which year was gross margin highest? Is coverage improving?

### Expected output (approximate)

```
fiscal_year  gross_margin_pct   ebit    interest_coverage
2019         42.86              755.0   8.88
...
```

### Discussion questions

- When is it better to fill a missing value vs. drop the row?
- What is the interest coverage ratio telling a credit analyst?
- Why is `regex=True` needed in `str.replace()` here?

---

## Exercise 3 — Merging Portfolio Holdings with Price Data

### Scenario

You manage five equity positions. A holdings table records how many shares you own and at what price you bought them. You need to compute your current portfolio value and unrealized P&L using today's closing prices.

### Tasks

1. Load `portfolio_holdings.csv` and `stock_prices.csv`.
2. Filter prices to the most recent available date (do not hardcode the date).
3. Left-join holdings onto latest prices on `Ticker`. Verify no nulls in `Close`.
4. Compute `market_value`, `cost_basis`, `unrealized_pnl`, and `pnl_pct`.
5. Report total portfolio value, total P&L, and overall return %.
6. **Bonus:** Add position weights and identify the largest holding.

### Expected output (approximate)

```
Total market value:    $143,250
Total unrealized P&L:  $18,900
Total return:          15.2%

Best position:  AMZN  +28.4%
Worst position: JPM    +6.1%
```

### Discussion questions

- Why use a left join rather than an inner join here?
- What happens if a ticker in holdings has no price record?
- How would you extend this to show daily P&L over the holding period?

---

## Exercise 4 — Computing Rolling Returns and Volatility

### Scenario

You are building a risk dashboard. The key input: 30-day rolling annualized volatility for each stock, derived from daily log returns. This is also the realized volatility input to options pricing models.

### Finance concepts to review before starting

- **Log return:** `ln(Pₜ / Pₜ₋₁)` — preferred over simple returns because they are additive across time
- **Annualization:** multiply daily vol by `√252` (the number of trading days per year)
- **Rolling window:** a 30-day window updates every day — each observation uses the prior 30 days

### Tasks

1. Compute daily log returns per ticker using `groupby` + `shift`.
2. Compute 30-day rolling std per ticker and annualize. Name the column `vol_30d`.
3. Find the 5 date-ticker observations with the highest rolling vol.
4. Resample to monthly frequency: average `vol_30d` per ticker per month.
5. Compute correlation of each stock's returns with the S&P 500.
6. **Bonus:** Plot the rolling vol for all tickers on one chart.

### Expected output (approximate)

```
Top 5 highest vol windows:
   Date        Ticker  vol_30d
   2023-03-15  GS      0.412
   ...

Monthly vol (excerpt):
   Ticker  Date       vol_30d
   AAPL    2023-01    0.241
   ...
```

### Discussion questions

- Why do we use log returns rather than percentage returns here?
- What does it mean if a stock's correlation with the S&P 500 is 0.9?
- How would you interpret a spike in rolling vol for a single stock?

---

## Exercise 5 — Multi-Company Financial Ratio Dashboard

### Scenario

You are a credit analyst covering 10 companies across 5 years of quarterly data. The data arrives in wide format. You need to reshape it, compute four standard ratios, detect companies with deteriorating ROE, and produce a peer-comparison dashboard.

### Finance concepts to review

| Ratio | Formula | What it measures |
|---|---|---|
| P/E | Price / EPS | Valuation vs. earnings |
| Debt/Equity | Total Debt / Total Equity | Financial leverage |
| Current Ratio | Current Assets / Current Liabilities | Short-term liquidity |
| ROE | Net Income / Equity × 4 | Annualized return on equity |

### Tasks

1. Load `quarterly_financials.csv`. Melt all metric columns into long format.
2. Pivot back to a (Company, Quarter) × metric layout.
3. Compute all four ratios. Handle divide-by-zero safely.
4. Compute YoY ROE change using `pct_change(4)`. Flag companies where ROE fell >20%.
5. Build a pivot table of latest-quarter ratios, sorted by ROE descending.
6. Style the table: green = top quartile, red = bottom quartile.
7. **Bonus:** Rank companies by consistency of Current Ratio using a 4-quarter rolling mean.

### Discussion questions

- Why is annualizing ROE (×4) important when using quarterly figures?
- A Current Ratio of 0.8 — is that alarming? Does it depend on the industry?
- What are the limitations of comparing P/E across companies in different sectors?

---

## Exercise 6 — Earnings Surprise Event Study

### Scenario

You want to quantify how much a positive earnings surprise moves a stock price, and whether the effect is statistically significant. This is a standard empirical finance method — used in CFA research, M&A due diligence, and academic finance papers.

### Finance concepts to review

- **Abnormal return:** actual return minus what the market returned on the same day
- **CAR (cumulative abnormal return):** sum of daily abnormal returns over the event window
- **Event window [−5, +5]:** captures both anticipation before and reaction after the announcement
- **t-test:** tests whether the average CAR for "Beat" events is meaningfully different from zero

### Tasks

1. Load all three files. Compute log returns for stocks and the S&P 500.
2. For each earnings event, find the matching trading day (forward-fill weekends/holidays).
3. Write `get_car()` that slices the [−5, +5] window and sums abnormal returns.
4. Classify events as Beat (>+2%), Miss (<−2%), or Meet.
5. Report mean CAR per group — does the pattern match intuition?
6. Run a one-sample t-test on the Beat group. Is the result significant at p < 0.05?
7. **Bonus:** Plot the day-by-day cumulative average return path for Beat vs. Miss.

### Expected output (approximate)

```
Mean CAR by group:
  Beat:  +0.0312  (+3.1%)
  Meet:  +0.0041
  Miss:  -0.0278

t-test (Beat group, H₀: mean CAR = 0)
  t-statistic : 2.84
  p-value     : 0.018
  Significant at 5%: True
```

### Discussion questions

- Why use log returns rather than price levels in the event study?
- What is the interpretation of a statistically significant positive CAR for "Beat"?
- What confounding factors might make this event study noisy (e.g., macro events)?
- How would you strengthen this study with more data or a better benchmark?

---

## Reference: Key Pandas Patterns

```python
# Load with date parsing
pd.read_csv("file.csv", parse_dates=["Date"])

# Clean messy string numbers
df["col"] = df["col"].str.replace(r"[$,M\s]", "", regex=True).astype(float)

# Filter to max date
df[df["Date"] == df["Date"].max()]

# Merge two tables
pd.merge(left, right, on="Ticker", how="left")

# Log returns per group
df["log_ret"] = df.groupby("Ticker")["Close"].transform(
    lambda x: np.log(x / x.shift(1))
)

# Rolling window per group
df["vol_30d"] = df.groupby("Ticker")["log_ret"].transform(
    lambda x: x.rolling(30).std() * np.sqrt(252)
)

# Melt wide → long
df.melt(id_vars=["Company","Quarter"], var_name="Metric", value_name="Value")

# Pivot long → wide
df.pivot_table(index=["Company","Quarter"], columns="Metric", values="Value")

# YoY change (quarterly data)
df["YoY"] = df.groupby("Company")["ROE"].pct_change(4)

# T-test
from scipy import stats
stats.ttest_1samp(sample_array, popmean=0)
```
