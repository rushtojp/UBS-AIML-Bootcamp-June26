# Trainer Notes — Python for Finance: Data Wrangling Lab
### MBA Finance Program

---

## Before the Session

### Room / environment checklist

- [ ] Python 3.9+ installed on student machines (or Jupyter hub provisioned)
- [ ] Run `pip install pandas numpy scipy matplotlib` — do this before class starts
- [ ] Run `python generate_datasets.py` on at least one machine to verify output
- [ ] Share the `mba_python_lab/` folder (USB, shared drive, or GitHub link)
- [ ] Have a working `solutions/` folder ready but instruct students not to open it during exercises
- [ ] Keep a terminal or REPL open on the projector

### Suggested session formats

| Format | Duration | Coverage |
|---|---|---|
| Full workshop | 4 hours | All 6 exercises + discussion |
| Half-day intro | 2 hours | Ex 1–3 only |
| Advanced session | 2 hours | Ex 4–6 (assumes prior pandas exposure) |
| Flipped classroom | Exercises as homework | Use class time for discussion only |

---

## Exercise 1 — Loading and Inspecting Stock Prices

**Targeted skills:** `read_csv`, `dtypes`, `isnull`, `groupby`, `idxmax`  
**Estimated time:** 20–25 minutes  
**Common errors:** 30 minutes if students are truly new to pandas

### Trainer tips

**Date parsing is the #1 stumbling block.** Students will often load the CSV and then be surprised that `Date` shows up as object/string. Walk through what `parse_dates=["Date"]` does and why datetime operations (filtering by year, resampling) require it.

**`idxmax()` confusion.** Students often expect `idxmax()` to return the value, not the index. Clarify: it returns a label, which you then pass to `.loc[]`. Write this on the board:

```python
idx = df["Close"].idxmax()   # → an integer index
df.loc[idx]                  # → the row
```

**`groupby + agg` syntax.** Two common forms to show side-by-side:

```python
# Form 1: list of functions
df.groupby("Ticker")["Close"].agg(["mean","min","max"])

# Form 2: named dict (cleaner column names)
df.groupby("Ticker")["Close"].agg(mean_close="mean", min_close="min")
```

### Discussion debrief (5 min)

Ask: "If you were presenting to the investment committee, which of these numbers would you lead with — the mean price or the distribution of prices?" Lead toward: mean hides volatility; `describe()` gives a richer picture.

---

## Exercise 2 — Cleaning a Messy Income Statement

**Targeted skills:** `str.replace`, `astype`, `rename`/column rename, `fillna`, ratio derivation  
**Estimated time:** 30–40 minutes  
**This is typically the hardest beginner exercise.**

### Trainer tips

**The "$4,200M" parsing problem.** Students will inevitably try `int("$4,200M")` and hit a `ValueError`. Use this as a teachable moment about how `str.replace` with `regex=True` works:

```python
# Show step by step — don't just show the finished line
s = "$4,200M"
s = s.replace("$", "")   # "4,200M"
s = s.replace(",", "")   # "4200M"
s = s.replace("M", "")   # "4200"
float(s)                  # 4200.0
```

Then show how `str.replace(r"[$,M\s]", "", regex=True)` condenses all of that.

**Column renaming gotcha.** Students often try `df.rename({"old": "new"})` and forget `columns=` or `inplace=True`. Show:

```python
df.columns = df.columns.str.strip().str.lower().str.replace(" ","_")
# This replaces all columns at once — cleaner than rename() for bulk standardization
```

**Missing value pedagogy.** This exercise has a deliberate missing value in `Interest Expense`. Use it to teach the decision framework:

| Situation | Approach |
|---|---|
| Missing at random, few rows | Fill with median or mean |
| Systematically missing (e.g., no interest = no debt) | Fill with 0 — it's meaningful |
| Critical identifier field | Drop the row |
| Suspicious pattern | Flag for investigation before any action |

In this case, interior missing in a 5-row time series → fill with median.

### Common student mistake

Forgetting that `str.replace` is a method on a `Series`, not a `DataFrame`. Students will try `df.str.replace(...)` and get `AttributeError`. Remind them to select the column first.

### Discussion debrief (5 min)

Ask: "An interest coverage ratio of 1.2 vs. 8.8 — what does that mean for a credit analyst?" Lead toward: coverage below 1.5 is considered distressed; lenders use it as a covenant trigger.

---

## Exercise 3 — Merging Portfolio Holdings with Price Data

**Targeted skills:** filter to max date, `merge`, column arithmetic, `sum`, positional best/worst  
**Estimated time:** 25–35 minutes

### Trainer tips

**"Don't hardcode the date" — make this a principle.** Students will almost always write `prices[prices["Date"] == "2023-12-29"]`. When they do, ask: "What happens when you get January's data file next month?" This is the moment to establish the habit of `prices["Date"].max()`.

**Left join vs. inner join.** This scenario is a perfect teaching example:

```
Holdings:  AAPL, MSFT, JPM, GS, AMZN   (5 rows)
Prices:    AAPL, MSFT, JPM, GS, AMZN + potentially others

Inner join → only tickers in BOTH tables (correct here, but fragile)
Left join  → all holdings, fills NaN if no price found (safer — you'll notice the NaN)
```

Right-join or full outer join would be unusual here — help students reason about which table is the "driver."

**Column arithmetic vs. apply.** For simple element-wise math, show that direct column arithmetic is preferable:

```python
# Preferred (vectorized, fast)
portfolio["market_value"] = portfolio["Shares"] * portfolio["Close"]

# Avoid for simple math (slow, verbose)
portfolio["market_value"] = portfolio.apply(lambda row: row["Shares"] * row["Close"], axis=1)
```

### Common student mistake

Forgetting to filter latest_prices before the merge, resulting in a many-to-many join where each holding matches every date's price row. The resulting shape (holdings × 252 dates) is a tell.

### Discussion debrief (5 min)

Ask: "What additional columns would a real portfolio system track that we haven't computed?" Expect: dividends received, currency exposure, beta, benchmark attribution. Use this to preview what data wrangling skills unlock.

---

## Exercise 4 — Rolling Returns and Volatility

**Targeted skills:** `shift`, `np.log`, `rolling`, `transform`, `resample`, correlation  
**Estimated time:** 40–50 minutes  
**This is the pivot exercise — students move from finance facts to quantitative methods.**

### Finance concept setup (recommend 5-min whiteboard before students start)

Draw the timeline:

```
Day 0: P = 100
Day 1: P = 102  →  log_ret = ln(102/100) = 0.0198
Day 2: P = 99   →  log_ret = ln(99/102)  = -0.0299

30-day window: std(log_ret) × √252 = annualized vol
```

Explain why `√252`: if daily vol is σ, then by Brownian motion, annual vol is σ × √(trading days). This is the "square-root-of-time rule."

### Trainer tips

**The groupby + transform pattern** is the most important pattern in this lab. Students who internalize it will be able to handle any per-group rolling computation. Write it slowly:

```python
# WITHOUT groupby — wrong: bleeds across tickers
df["log_ret"] = np.log(df["Close"] / df["Close"].shift(1))  # ❌

# WITH groupby — correct: shift happens within each ticker
df["log_ret"] = df.groupby("Ticker")["Close"].transform(
    lambda x: np.log(x / x.shift(1))
)  # ✓
```

Ask students: "Without groupby, what happens to MSFT's first log_ret if the last AAPL row is adjacent?" This catches the issue intuitively.

**`resample` requires a DatetimeIndex.** A very common error:

```python
df.resample("ME")["vol_30d"].mean()  # ❌ KeyError if Date is a column
df.set_index("Date").resample("ME")["vol_30d"].mean()  # ✓
```

### Common student mistake

Using `rolling(30).std()` directly on the full DataFrame without `groupby` — the rolling window will span across tickers. Running `df.groupby("Ticker").apply(lambda g: g.rolling(30).std())` also works but produces MultiIndex output that confuses students. Prefer `transform`.

### Discussion debrief (5 min)

Ask: "If GS has the highest correlation with the S&P 500 in our dataset, what does that imply for hedging?" Lead toward: high correlation → harder to hedge using the index; need something with lower correlation for diversification.

---

## Exercise 5 — Multi-Company Financial Ratio Dashboard

**Targeted skills:** `melt`, `pivot_table`, ratio computation, `pct_change`, `Styler`  
**Estimated time:** 45–60 minutes  
**This exercise mirrors a real equity research workflow.**

### Finance concept setup (5-min whiteboard)

Show the wide → long → compute → pivot workflow:

```
Wide (raw):   Company | Q1_Revenue | Q2_Revenue | Q1_COGS | ...
                              ↓  melt()
Long (tidy):  Company | Quarter | Metric    | Value
                              ↓  pivot_table()
Compute:      Company | Quarter | Revenue   | COGS | Equity | ...
                              ↓  arithmetic
Ratios:       Company | Quarter | ROE | DE  | CR   | PE
                              ↓  groupby + pct_change(4)
Flags:        Companies where ROE fell >20% YoY
```

### Trainer tips

**`pivot_table` column names.** After pivoting, the columns will have `name = 'Metric'`, which causes a `columns.name` attribute that can interfere with display. Teach:

```python
ratios.columns.name = None
```

**Why `pct_change(4)` not `pct_change(1)`?** Quarterly data has seasonality — a retailer's Q4 is always larger than Q1 regardless of growth. YoY (4 quarters) removes seasonality. `pct_change(1)` compares Q2 to Q1, which is meaningless for retail. Make this explicit.

**`Styler` for presentation.** The pandas Styler is underused in finance contexts. Show that:

```python
styled.to_excel("dashboard.xlsx", engine="openpyxl")
```

produces a directly presentable Excel file — this resonates strongly with MBA students who live in Excel.

### Common student mistake

After `melt` + `pivot_table`, students often get confused by the MultiIndex columns and try to access `ratios["Revenue"]` when the column is `("Value", "Revenue")`. The fix: `reset_index()` and `ratios.columns.name = None`.

### Discussion debrief (5 min)

Ask: "A company has a Current Ratio of 0.6 and a Debt/Equity of 2.5 — what's your instinct as an analyst?" Lead toward: depends heavily on industry. Airlines, utilities carry high debt by design. A tech company with those ratios would be alarming. This motivates sector-adjusted benchmarking.

---

## Exercise 6 — Earnings Surprise Event Study

**Targeted skills:** date alignment, index-based window slicing, `apply`, groupby, `scipy.stats`  
**Estimated time:** 50–70 minutes  
**This is a graduate-level empirical finance method. Allow extra time.**

### Finance concept setup (8-min whiteboard before starting)

Draw the event timeline on the board:

```
            t-5  t-4  t-3  t-2  t-1  t=0  t+1  t+2  t+3  t+4  t+5
                                       ↑
                                  Earnings
                                announcement

Abnormal return on each day = stock_ret − market_ret
CAR = Σ abnormal_ret over [t-5, t+5]
```

Explain the logic: if markets are efficient, the CAR should be zero in the pre-period (t-5 to t-1) and should spike at t=0 only if the news is a genuine surprise. A positive CAR for "Beat" events confirms the surprise isn't priced in.

### Trainer tips

**The date alignment problem.** Earnings announcements are sometimes on weekends or holidays. Show `searchsorted` as the clean solution:

```python
trading_days = prices["Date"].drop_duplicates().sort_values()
# searchsorted gives the index of where Ann_Date would be inserted
# That index points to the next trading day if the exact date doesn't exist
```

This is a real problem analysts face when using Bloomberg or Compustat data.

**`apply` is slow on large datasets.** For this lab with 20 events, it's fine. If students ask about scaling, mention `merge_asof` as the production-grade approach for time-series alignment.

**The `get_car` function architecture.** Walk students through the three responsibilities inside the function:
1. Filter to the right ticker
2. Find the center index
3. Slice the window, merge market returns, sum abnormal returns

Encourage them to test the function on one row before applying it to all.

**T-test interpretation.** Many MBA students have statistics in their background but haven't connected it to finance. Walk through:

```
H₀ (null):  Mean CAR for Beat events = 0   (market ignores earnings beats)
H₁ (alternative): Mean CAR ≠ 0

If p < 0.05: reject H₀ — there IS a statistically significant reaction to earnings beats
```

With 20 events across 5 tickers × 4 quarters, the sample may be too small for significance. Acknowledge this — it's a real limitation, and a good teachable moment about statistical power.

### Common student mistake

Using `.loc[]` with date values to slice the window instead of positional index `.iloc[]`. Since the index is integer after `reset_index()`, students need to slice with positional offsets from the center row, not by date arithmetic.

### Discussion debrief (10 min)

This is the richest discussion in the lab. Questions to ask:

1. "Our dataset has 20 earnings events. A real study would use how many?" (Hundreds to thousands — leads to power discussion)
2. "What confounds our CAR estimate?" (Macro news on the same day, sector-wide moves, pre-announcement leakage)
3. "What would you change about the benchmark?" (Market-cap-weighted sector index vs. S&P 500)
4. "How would this analysis help a merger arbitrage desk?" (Calibrate expected move on deal close announcement)

---

## Closing Discussion (15 min)

### Questions to ask the group

1. "Which exercise felt most directly applicable to your internship or career path?"
2. "What manual Excel workflow could any of today's exercises replace in a real job?"
3. "What's the main advantage of Python over Excel for this kind of work?" (Scale, reproducibility, version control, integration with APIs)
4. "What would you need to learn next to make these exercises production-ready?" (Database connections, API access, scheduling, dashboarding with Streamlit/Dash)

### Where to go from here

Point students toward:
- `yfinance` for free real-time price data from Yahoo Finance
- `pandas_datareader` for FRED economic data
- `wrds` for Compustat and CRSP (available through most business school libraries)
- Streamlit for turning these scripts into interactive dashboards

---

## Grading Rubric (if used as an assessment)

| Criterion | Points |
|---|---|
| Code runs without errors | 30 |
| Correct numerical output for core tasks | 40 |
| Handles edge cases (missing values, weekends, divide-by-zero) | 15 |
| Bonus task completed | 10 |
| Code is readable (variable names, no redundancy) | 5 |

**Total: 100 points per exercise**

For group work: add a 5-min verbal explanation of one chosen exercise to test individual understanding.
