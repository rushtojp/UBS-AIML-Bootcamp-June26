# Machine Learning for Finance — Loan Default Demo Kit

A complete, self-contained teaching kit that walks MBA finance students through an
**end-to-end machine-learning project** on a realistic credit-risk problem, using
**100% synthetic data**. Every stage explains not just *what* is done but *why it
matters to the business* — and the demo finishes where finance students care most:
**dollars of profit**, not abstract accuracy.

---

## What's in the box

| File | Audience | Purpose |
|---|---|---|
| **01_Participant_Guide.docx** | Students | The core courseware. Walks all six ML lifecycle stages with figures, benefit callouts, results, a responsible-lending section, a hands-on exercise, and a glossary. |
| **02_Trainer_Deck.pptx** | Instructor | 10-slide teaching deck with speaker notes, mirroring the guide. |
| **03_Decision_Workbook.xlsx** | Students | Interactive Excel model. Set a decline cut-off and LGD assumption; profit recalculates live. Includes an Expected-Loss calculator. |
| **data/loan_applications.csv** | All | The synthetic 8,000-loan dataset. |
| **data/scored_sample.csv** | All | 50 model-scored loans that power the Excel workbook. |
| **code/01_generate_data.py** | All | Generates the dataset (fully commented; shows *how* synthetic data is built). |
| **code/02_solution_pipeline.py** | Instructor | The complete worked solution — reproduces every figure and metric. |
| **code/03_student_scaffold.py** | Students | The same pipeline with key lines left as TODOs for the hands-on lab. |
| **figures/** | All | The six charts used across the guide and deck. |

---

## The scenario

Students play a **retail-bank analyst** deciding who to lend to. They build a model that
estimates each applicant's **probability of default (PD)**, then convert that probability
into a lending policy using the credit-risk identity:

> **Expected Loss = PD × LGD × EAD**

The punchline: moving from "approve everyone" to the model-optimal cut-off swings the test
portfolio from a **~$0.6M loss to a ~$1.8M profit** (a ~$2.4M uplift).

## The six stages taught

1. **Business Understanding** — define the decision in dollars (PD, LGD, EAD).
2. **Data Understanding (EDA)** — look before you model; find the risk drivers.
3. **Data Preparation** — split *first*, then transform; avoid data leakage.
4. **Modeling** — interpretable Logistic Regression vs. Gradient Boosting.
5. **Evaluation** — escape the "accuracy trap"; use ROC-AUC and the confusion matrix.
6. **Business Decision** — sweep the cut-off; pick the profit-maximising policy.

---

## Running the code (optional live demo)

Requires Python 3 with `pandas`, `numpy`, `scikit-learn`, `matplotlib`.

```bash
cd code
python 01_generate_data.py        # writes data/loan_applications.csv
python 02_solution_pipeline.py    # writes all figures + results_summary.json
```

Expected results: overall default rate ≈ **17%**, model ROC-AUC ≈ **0.89**.

> The dataset ships pre-generated, so the guide, deck, and workbook work with **no code
> required**. Running the code is for classes that want to see the pipeline live.

---

## Suggested 60-minute session flow

| Time | Activity |
|---|---|
| 0–10 min | Deck slides 1–3: the business problem and the six-stage lifecycle. |
| 10–30 min | Deck slides 4–8: walk the pipeline; show each figure and its benefit. |
| 30–45 min | Students open **03_Decision_Workbook.xlsx**; find the profit-maximising cut-off. |
| 45–55 min | Deck slide 9: responsible-lending discussion (fairness, explainability, monitoring). |
| 55–60 min | Wrap with slide 10 takeaways; assign the guide's exercise as follow-up. |

---

*All data is synthetic and generated for teaching. No real borrower information is used.*
*Aarvi Learning Solutions — Training & Enablement.*
