"""
=============================================================================
 02_solution_pipeline.py  —  End-to-End Credit-Risk ML (INSTRUCTOR SOLUTION)
=============================================================================
This is the fully-worked solution for the demo. It follows the standard
industry lifecycle (CRISP-DM): Business Understanding -> Data Understanding
-> Data Preparation -> Modeling -> Evaluation -> Business Decision.

Every stage prints what it did and WHY it matters for a lender, and saves a
figure the trainer can drop into slides. Run:  python 02_solution_pipeline.py
=============================================================================
"""
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import (roc_auc_score, roc_curve, confusion_matrix,
                             classification_report, accuracy_score)

warnings.filterwarnings("ignore")
plt.rcParams.update({"figure.dpi": 130, "font.size": 11, "axes.grid": True,
                     "grid.alpha": 0.25, "axes.axisbelow": True})
NAVY, TEAL, CORAL, GREY = "#1E2761", "#028090", "#F96167", "#8A8D93"
FIG = "../figures"
results = {}   # collected metrics we export for the courseware

# =============================================================================
# STAGE 0 — BUSINESS UNDERSTANDING  (framed here as constants we will use)
# =============================================================================
# When a loan defaults the bank does not lose the whole balance — it recovers
# some through collections/collateral. Two standard credit-risk parameters:
LGD = 0.55        # Loss Given Default: fraction of balance lost when default occurs
# Approving a GOOD loan earns interest margin; approving a BAD loan loses LGD*balance.
# We will turn model scores into $ decisions at the end using these.

# =============================================================================
# STAGE 1 — DATA UNDERSTANDING  (Exploratory Data Analysis)
# WHY: before modeling, understand the shape of risk. This is where a credit
# officer builds intuition and sanity-checks the data.
# =============================================================================
df = pd.read_csv("../data/loan_applications.csv")
n, default_rate = len(df), df["default"].mean()
results["n_loans"] = n
results["default_rate"] = round(default_rate, 4)
print(f"[EDA] {n:,} loans | overall default rate = {default_rate:.1%}")

# Figure 1: class balance — shows WHY accuracy alone is misleading.
fig, ax = plt.subplots(figsize=(5.2, 4))
counts = df["default"].value_counts().sort_index()
ax.bar(["Repaid (0)", "Defaulted (1)"], counts.values, color=[TEAL, CORAL])
for i, v in enumerate(counts.values):
    ax.text(i, v + 60, f"{v:,}\n({v/n:.0%})", ha="center", fontweight="bold")
ax.set_title("Class balance: most loans are repaid", fontweight="bold")
ax.set_ylabel("Number of loans")
plt.tight_layout(); plt.savefig(f"{FIG}/fig1_class_balance.png"); plt.close()

# Figure 2: default rate by credit-score band — the headline risk driver.
bands = pd.cut(df["credit_score"],
               bins=[300, 580, 640, 680, 720, 760, 850],
               labels=["<580", "580-639", "640-679", "680-719", "720-759", "760+"])
by_band = df.groupby(bands, observed=True)["default"].mean()
fig, ax = plt.subplots(figsize=(6.2, 4))
ax.bar(by_band.index.astype(str), by_band.values * 100, color=NAVY)
for i, v in enumerate(by_band.values):
    ax.text(i, v * 100 + 0.6, f"{v:.0%}", ha="center", fontweight="bold")
ax.set_title("Default rate falls sharply as credit score rises", fontweight="bold")
ax.set_ylabel("Default rate (%)"); ax.set_xlabel("Credit-score band")
plt.tight_layout(); plt.savefig(f"{FIG}/fig2_default_by_score.png"); plt.close()
results["default_rate_low_score"] = round(float(by_band.iloc[0]), 3)
results["default_rate_high_score"] = round(float(by_band.iloc[-1]), 3)

# =============================================================================
# STAGE 2 — DATA PREPARATION
# WHY: models need clean, numeric, comparably-scaled inputs. We must NEVER let
# the model peek at test data ("leakage"), so we split FIRST, then fit all
# preprocessing on the training data only.
# =============================================================================
target = "default"
drop_cols = ["loan_id", target]
X = df.drop(columns=drop_cols)
y = df[target]

numeric = ["age", "annual_income", "employment_years", "credit_score",
           "num_existing_loans", "num_late_payments_2yr", "loan_amount",
           "loan_term_months", "interest_rate", "debt_to_income"]
categorical = ["home_ownership", "loan_purpose", "region"]

# 70/30 stratified split keeps the default rate identical in train and test.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)
results["n_train"], results["n_test"] = len(X_train), len(X_test)
print(f"[PREP] train={len(X_train):,}  test={len(X_test):,} (stratified split)")

# Preprocessing recipe: impute missing numerics -> scale; one-hot the categoricals.
numeric_pipe = Pipeline([("impute", SimpleImputer(strategy="median")),
                         ("scale", StandardScaler())])
categorical_pipe = Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                             ("onehot", OneHotEncoder(handle_unknown="ignore"))])
preprocess = ColumnTransformer([("num", numeric_pipe, numeric),
                                ("cat", categorical_pipe, categorical)])

# =============================================================================
# STAGE 3 — MODELING
# We train TWO models on purpose:
#   (a) Logistic Regression — the interpretable industry standard. Its
#       coefficients translate to odds ratios a credit committee can read.
#   (b) Gradient Boosting — a stronger non-linear model that usually predicts
#       better but is harder to explain. The trade-off is the lesson.
# =============================================================================
logit = Pipeline([("prep", preprocess),
                  ("clf", LogisticRegression(max_iter=2000, class_weight="balanced"))])
gbm = Pipeline([("prep", preprocess),
                ("clf", GradientBoostingClassifier(random_state=42))])

logit.fit(X_train, y_train)
gbm.fit(X_train, y_train)
print("[MODEL] trained Logistic Regression and Gradient Boosting")

# Predicted probability of default (PD) for each test loan.
p_logit = logit.predict_proba(X_test)[:, 1]
p_gbm = gbm.predict_proba(X_test)[:, 1]

# =============================================================================
# STAGE 4 — EVALUATION
# WHY accuracy is a trap: a lazy model that predicts "nobody defaults" is
# ~83% accurate here yet approves every bad loan. We use ROC-AUC (ranking
# quality) and a confusion matrix (business errors) instead.
# =============================================================================
naive_acc = 1 - default_rate           # "approve everyone" baseline accuracy
auc_logit = roc_auc_score(y_test, p_logit)
auc_gbm = roc_auc_score(y_test, p_gbm)
results.update({"naive_accuracy": round(naive_acc, 4),
                "auc_logit": round(auc_logit, 4),
                "auc_gbm": round(auc_gbm, 4)})
print(f"[EVAL] naive 'approve-all' accuracy = {naive_acc:.1%}")
print(f"[EVAL] AUC  logistic={auc_logit:.3f}   gradient-boosting={auc_gbm:.3f}")

# Figure 3: ROC curves comparing the two models to random guessing.
fig, ax = plt.subplots(figsize=(5.6, 5))
for p, name, c in [(p_logit, f"Logistic  (AUC {auc_logit:.2f})", TEAL),
                   (p_gbm, f"Gradient Boosting  (AUC {auc_gbm:.2f})", NAVY)]:
    fpr, tpr, _ = roc_curve(y_test, p)
    ax.plot(fpr, tpr, label=name, lw=2.4, color=c)
ax.plot([0, 1], [0, 1], "--", color=GREY, label="Random guess (AUC 0.50)")
ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
ax.set_title("ROC curve: both models beat guessing", fontweight="bold")
ax.legend(loc="lower right", fontsize=9)
plt.tight_layout(); plt.savefig(f"{FIG}/fig3_roc.png"); plt.close()

# Pick the better model BY AUC for the business analysis. Teaching point: the
# fancier model is not automatically better. Here the interpretable logistic
# model wins, because the underlying risk relationships are close to linear.
if auc_logit >= auc_gbm:
    best_p, best_name = p_logit, "Logistic Regression"
else:
    best_p, best_name = p_gbm, "Gradient Boosting"
results["best_model"] = best_name
print(f"[EVAL] selected best model by AUC: {best_name}")
pred_50 = (best_p >= 0.50).astype(int)
cm = confusion_matrix(y_test, pred_50)
tn, fp, fn, tp = cm.ravel()
results["confusion_at_0.50"] = {"tn": int(tn), "fp": int(fp),
                                "fn": int(fn), "tp": int(tp)}
print("[EVAL] confusion matrix @0.50:\n", classification_report(y_test, pred_50,
      target_names=["Repaid", "Default"]))

# Figure 4: confusion matrix with business labels.
fig, ax = plt.subplots(figsize=(5.2, 4.6))
ax.imshow(cm, cmap="Blues")
labels = [["True Negative\n(good loan approved)", "False Positive\n(good loan rejected)"],
          ["False Negative\n(bad loan approved)", "True Positive\n(bad loan caught)"]]
for i in range(2):
    for j in range(2):
        ax.text(j, i, f"{labels[i][j]}\n\n{cm[i, j]:,}", ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else NAVY, fontweight="bold",
                fontsize=9)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Predicted repaid", "Predicted default"])
ax.set_yticks([0, 1]); ax.set_yticklabels(["Actually repaid", "Actually default"])
ax.set_title(f"Confusion matrix ({best_name} @ 0.50)", fontweight="bold")
plt.tight_layout(); plt.savefig(f"{FIG}/fig4_confusion.png"); plt.close()

# =============================================================================
# STAGE 5 — INTERPRETATION  (WHY the model decides what it decides)
# =============================================================================
# 5a. Logistic coefficients -> odds ratios. OR>1 raises default odds; <1 lowers.
feat_names = (numeric +
              list(logit.named_steps["prep"]
                   .named_transformers_["cat"]["onehot"]
                   .get_feature_names_out(categorical)))
coefs = logit.named_steps["clf"].coef_[0]
odds = pd.Series(np.exp(coefs), index=feat_names).sort_values()
results["top_risk_increasers"] = odds.tail(4).round(2).to_dict()
results["top_risk_reducers"] = odds.head(4).round(2).to_dict()

# 5b. Gradient-boosting feature importance (which inputs it relied on most).
importances = pd.Series(
    gbm.named_steps["clf"].feature_importances_, index=feat_names
).sort_values(ascending=False).head(10)
results["top_gbm_features"] = importances.round(3).to_dict()

fig, ax = plt.subplots(figsize=(6.6, 4.6))
importances[::-1].plot.barh(ax=ax, color=NAVY)
ax.set_title("What drives the prediction (Gradient Boosting)", fontweight="bold")
ax.set_xlabel("Relative importance")
plt.tight_layout(); plt.savefig(f"{FIG}/fig5_feature_importance.png"); plt.close()

# =============================================================================
# STAGE 6 — FROM PROBABILITY TO PROFIT  (the MBA payoff)
# A model outputs a probability. The BUSINESS question is: at what PD do we
# decline a loan? We sweep the cut-off and compute portfolio economics.
# =============================================================================
bal = X_test["loan_amount"].values                  # exposure at default per loan
rate = X_test["interest_rate"].values / 100.0
term_yrs = X_test["loan_term_months"].values / 12.0
# Simplified per-loan economics used ONLY for the teaching demo:
#   - Approve a loan that repays  -> earn interest margin over the life
#   - Approve a loan that defaults -> lose LGD * balance
margin_if_good = bal * rate * term_yrs * 0.5        # rough net interest margin
loss_if_bad = bal * LGD

thresholds = np.linspace(0.05, 0.95, 91)
net_profit, approval_rate, caught = [], [], []
for t in thresholds:
    approve = best_p < t                            # approve if PD below cut-off
    good = approve & (y_test.values == 0)
    bad = approve & (y_test.values == 1)
    profit = margin_if_good[good].sum() - loss_if_bad[bad].sum()
    net_profit.append(profit)
    approval_rate.append(approve.mean())
    caught.append(((~approve) & (y_test.values == 1)).sum() /
                  max((y_test.values == 1).sum(), 1))

net_profit = np.array(net_profit)
best_idx = int(net_profit.argmax())
best_threshold = float(thresholds[best_idx])
results["best_threshold"] = round(best_threshold, 3)
results["profit_at_best"] = round(float(net_profit[best_idx]), 0)
results["approval_rate_at_best"] = round(float(approval_rate[best_idx]), 3)
# Compare against approving everyone (threshold ~ 1.0).
profit_approve_all = (margin_if_good[y_test.values == 0].sum()
                      - loss_if_bad[y_test.values == 1].sum())
results["profit_approve_all"] = round(float(profit_approve_all), 0)
results["profit_uplift"] = round(float(net_profit[best_idx] - profit_approve_all), 0)
print(f"[BIZ] optimal PD cut-off = {best_threshold:.2f} "
      f"| approve {approval_rate[best_idx]:.0%} of applicants")
print(f"[BIZ] test-set profit: model ${net_profit[best_idx]:,.0f} "
      f"vs approve-all ${profit_approve_all:,.0f} "
      f"(uplift ${net_profit[best_idx]-profit_approve_all:,.0f})")

# Figure 6: profit vs cut-off, with the optimum marked.
fig, ax = plt.subplots(figsize=(6.8, 4.6))
ax.plot(thresholds, net_profit / 1e6, color=NAVY, lw=2.6, label="Model policy")
ax.axhline(profit_approve_all / 1e6, ls="--", color=CORAL,
           label="Approve everyone")
ax.axvline(best_threshold, ls=":", color=TEAL)
ax.scatter([best_threshold], [net_profit[best_idx] / 1e6], color=TEAL, zorder=5,
           s=70, label=f"Optimal cut-off = {best_threshold:.2f}")
ax.set_xlabel("Decline loans above this predicted default probability")
ax.set_ylabel("Test-portfolio net profit ($M)")
ax.set_title("Choosing the cut-off is a business decision", fontweight="bold")
ax.legend(fontsize=9)
plt.tight_layout(); plt.savefig(f"{FIG}/fig6_threshold_profit.png"); plt.close()

# =============================================================================
# EXPORT metrics for the courseware documents.
# =============================================================================
with open("../data/results_summary.json", "w") as f:
    json.dump(results, f, indent=2)
print("\n[DONE] figures saved to ../figures ; metrics -> ../data/results_summary.json")
