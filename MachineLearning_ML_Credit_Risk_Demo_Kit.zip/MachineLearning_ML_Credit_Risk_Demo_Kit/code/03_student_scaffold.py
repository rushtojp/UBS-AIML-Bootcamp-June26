"""
=============================================================================
 03_student_scaffold.py  —  STUDENT WORKBOOK (fill in the TODOs)
=============================================================================
Work top-to-bottom. Each TODO is one or two lines. When your output matches
the numbers in the Participant Guide (default rate ~17%, AUC ~0.89), you have
it right. The full answer key is 02_solution_pipeline.py.

Run:  python 03_student_scaffold.py
=============================================================================
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, confusion_matrix, classification_report

LGD = 0.55  # Loss Given Default assumption

# ---------------------------------------------------------------------------
# STAGE 1-2: Load and understand the data
# ---------------------------------------------------------------------------
df = pd.read_csv("../data/loan_applications.csv")

# TODO 1: print the overall default rate (hint: the mean of the 'default' column).
# default_rate = ...
# print(f"Default rate: {default_rate:.1%}")

# TODO 2: print the default rate for borrowers with credit_score >= 760 and < 580.
#         What does the gap tell you about credit score as a predictor?

# ---------------------------------------------------------------------------
# STAGE 3: Prepare the data (split FIRST, then transform)
# ---------------------------------------------------------------------------
numeric = ["age", "annual_income", "employment_years", "credit_score",
           "num_existing_loans", "num_late_payments_2yr", "loan_amount",
           "loan_term_months", "interest_rate", "debt_to_income"]
categorical = ["home_ownership", "loan_purpose", "region"]

X = df.drop(columns=["loan_id", "default"])
y = df["default"]

# TODO 3: create a 70/30 stratified train/test split with random_state=42.
# X_train, X_test, y_train, y_test = train_test_split(...)

numeric_pipe = Pipeline([("impute", SimpleImputer(strategy="median")),
                         ("scale", StandardScaler())])
categorical_pipe = Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                             ("onehot", OneHotEncoder(handle_unknown="ignore"))])
preprocess = ColumnTransformer([("num", numeric_pipe, numeric),
                                ("cat", categorical_pipe, categorical)])

# ---------------------------------------------------------------------------
# STAGE 4: Train a model
# ---------------------------------------------------------------------------
model = Pipeline([("prep", preprocess),
                  ("clf", LogisticRegression(max_iter=2000, class_weight="balanced"))])

# TODO 4: fit the model on the TRAINING data only.
# model.fit(...)

# TODO 5: get predicted default probabilities for the TEST set.
#         (hint: model.predict_proba(X_test)[:, 1])
# p_test = ...

# ---------------------------------------------------------------------------
# STAGE 5: Evaluate
# ---------------------------------------------------------------------------
# TODO 6: print the ROC-AUC (roc_auc_score(y_test, p_test)).
# TODO 7: print the confusion matrix at a 0.50 cut-off and read off how many
#         BAD loans were approved (false negatives).

# ---------------------------------------------------------------------------
# STAGE 6: Turn probability into a business decision
# ---------------------------------------------------------------------------
# TODO 8: sweep decline thresholds from 0.05 to 0.95. For each, approve loans
#         with predicted PD below the threshold, then compute portfolio profit:
#             + interest margin on approved-and-repaid loans
#             - LGD * balance on approved-and-defaulted loans
#         Find the threshold that maximises profit and compare it to approving
#         everyone. How much value does the model add?
#
# Starter economics (per test loan):
# bal   = X_test["loan_amount"].values
# rate  = X_test["interest_rate"].values / 100
# term  = X_test["loan_term_months"].values / 12
# margin_if_good = bal * rate * term * 0.5
# loss_if_bad    = bal * LGD
#
# for t in np.linspace(0.05, 0.95, 91):
#     approve = p_test < t
#     ...

print("Fill in the TODOs, then compare your numbers to the Participant Guide.")
