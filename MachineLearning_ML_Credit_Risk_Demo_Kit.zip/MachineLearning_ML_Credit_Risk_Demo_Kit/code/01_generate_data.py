"""
=============================================================================
 01_generate_data.py  —  Synthetic Loan Portfolio Generator
=============================================================================
PURPOSE
    Create a realistic, fully synthetic consumer-loan dataset for the
    "Machine Learning for Credit Risk" MBA demo. No real customer data is
    used, so the file is safe to share, email, and publish.

WHY SYNTHETIC DATA?
    - Privacy: real lending data is regulated (GLBA, GDPR, fair-lending law).
    - Control: we can bake in known relationships, so students can check
      whether the model "rediscovers" the drivers we planted.
    - Reproducibility: a fixed random seed means every student gets the
      identical dataset and the identical results.

WHAT WE MODEL
    A bank has issued N personal loans. For each borrower we record the
    information known AT THE TIME OF APPLICATION, plus the eventual outcome:
    did the loan DEFAULT (1) or was it repaid (0)?

    The probability of default (PD) is generated from a logistic function of
    a few genuine credit-risk drivers plus random noise. That gives the data
    a real signal for the model to find, while still being messy enough that
    no model can be perfect (just like the real world).
=============================================================================
"""

import numpy as np
import pandas as pd

RANDOM_SEED = 42
N = 8000  # number of loans in the portfolio
rng = np.random.default_rng(RANDOM_SEED)


# ---------------------------------------------------------------------------
# 1. Generate application-time features (what the bank knows before lending)
# ---------------------------------------------------------------------------
def make_features(n):
    # Borrower age (years). Clipped to a realistic lending range.
    age = np.clip(rng.normal(41, 12, n), 21, 75).round(0)

    # Annual gross income ($). Log-normal — most people cluster low, a few high.
    annual_income = np.clip(rng.lognormal(mean=11.0, sigma=0.45, size=n),
                            18_000, 400_000).round(-2)

    # Years at current employer. Longer tenure = more stability.
    employment_years = np.clip(rng.gamma(shape=2.2, scale=2.6, size=n), 0, 40).round(1)

    # FICO-style credit score (300–850). The single most important variable.
    credit_score = np.clip(rng.normal(690, 65, n), 300, 850).round(0)

    # Requested loan amount ($).
    loan_amount = np.clip(rng.lognormal(mean=9.4, sigma=0.55, size=n),
                          1_000, 60_000).round(-2)

    # Loan term in months (common consumer terms).
    loan_term_months = rng.choice([12, 24, 36, 48, 60], size=n,
                                  p=[0.10, 0.20, 0.35, 0.20, 0.15])

    # Number of other open loans/credit lines.
    num_existing_loans = rng.poisson(2.0, n).clip(0, 12)

    # Late payments in the last 2 years (delinquency history).
    num_late_payments_2yr = rng.poisson(0.6, n).clip(0, 15)

    # Categorical: home ownership status.
    home_ownership = rng.choice(["RENT", "MORTGAGE", "OWN"], size=n,
                                p=[0.42, 0.45, 0.13])

    # Categorical: stated purpose of the loan.
    loan_purpose = rng.choice(
        ["debt_consolidation", "credit_card", "home_improvement",
         "major_purchase", "medical", "small_business", "auto"],
        size=n, p=[0.30, 0.22, 0.14, 0.12, 0.08, 0.06, 0.08])

    # Categorical: region (adds a mild, realistic geographic effect).
    region = rng.choice(["Northeast", "Midwest", "South", "West"],
                        size=n, p=[0.22, 0.21, 0.34, 0.23])

    df = pd.DataFrame({
        "age": age,
        "annual_income": annual_income,
        "employment_years": employment_years,
        "credit_score": credit_score,
        "loan_amount": loan_amount,
        "loan_term_months": loan_term_months,
        "num_existing_loans": num_existing_loans,
        "num_late_payments_2yr": num_late_payments_2yr,
        "home_ownership": home_ownership,
        "loan_purpose": loan_purpose,
        "region": region,
    })

    # --- Engineered ratios that credit analysts actually use ----------------
    # Debt-to-income: monthly-ish loan burden vs income. Higher = riskier.
    est_monthly_payment = df["loan_amount"] / df["loan_term_months"]
    df["debt_to_income"] = np.clip(
        (est_monthly_payment * 12 + df["num_existing_loans"] * 2400)
        / df["annual_income"], 0.01, 3.0).round(3)

    # Interest rate offered (%). In reality the bank prices to risk: worse
    # credit -> higher rate. We build that in so the variable is informative.
    base_rate = 6.0
    rate = (base_rate
            + (720 - df["credit_score"]) * 0.035          # lower score -> higher rate
            + df["debt_to_income"] * 4.0                    # more leverage -> higher rate
            + df["num_late_payments_2yr"] * 0.4
            + rng.normal(0, 1.1, n))
    df["interest_rate"] = np.clip(rate, 3.5, 29.9).round(2)

    return df


# ---------------------------------------------------------------------------
# 2. Generate the OUTCOME (default) from a hidden "true" risk model
# ---------------------------------------------------------------------------
def add_default_outcome(df):
    """
    We combine the drivers into a latent log-odds score, convert to a
    probability of default, then flip a weighted coin per borrower.

    The coefficients below are the GROUND TRUTH. A good ML model should
    recover their DIRECTION (sign) even though it never sees them.
    """
    # Standardize a few numerics so coefficients are on a comparable scale.
    z = lambda s: (s - s.mean()) / s.std()

    log_odds = (
        -3.05                                        # baseline (sets overall default rate)
        - 1.15 * z(df["credit_score"])               # higher score  -> LOWER risk
        + 0.85 * z(df["debt_to_income"])             # higher DTI     -> higher risk
        + 0.80 * z(df["num_late_payments_2yr"])      # delinquency    -> higher risk
        + 0.55 * z(df["interest_rate"])              # higher rate    -> higher risk
        - 0.45 * z(df["annual_income"])              # higher income  -> lower risk
        - 0.35 * z(df["employment_years"])           # more tenure    -> lower risk
        + 0.30 * z(df["loan_amount"])                # bigger loan    -> higher risk
        + 0.20 * z(df["num_existing_loans"])
    )

    # Small categorical nudges (e.g., renters slightly riskier than owners).
    home_effect = df["home_ownership"].map(
        {"RENT": 0.25, "MORTGAGE": 0.0, "OWN": -0.20})
    purpose_effect = df["loan_purpose"].map(
        {"small_business": 0.45, "medical": 0.20, "debt_consolidation": 0.10,
         "credit_card": 0.08, "major_purchase": 0.0, "auto": -0.05,
         "home_improvement": -0.10})
    log_odds = log_odds + home_effect + purpose_effect

    # Add irreducible noise: real outcomes are never fully explained.
    log_odds = log_odds + rng.normal(0, 0.55, len(df))

    # Convert log-odds to probability, then sample the actual outcome.
    pd_true = 1 / (1 + np.exp(-log_odds))
    df["default"] = (rng.uniform(size=len(df)) < pd_true).astype(int)
    return df


# ---------------------------------------------------------------------------
# 3. Introduce a little realistic "messiness" (missing values)
# ---------------------------------------------------------------------------
def add_missingness(df):
    """A few fields are missing in the real world; students must handle it."""
    for col, frac in [("employment_years", 0.04), ("annual_income", 0.02)]:
        idx = rng.choice(df.index, size=int(frac * len(df)), replace=False)
        df.loc[idx, col] = np.nan
    return df


if __name__ == "__main__":
    df = make_features(N)
    df = add_default_outcome(df)
    df = add_missingness(df)

    # Give each loan an ID and reorder columns sensibly.
    df.insert(0, "loan_id", [f"L{100000 + i}" for i in range(len(df))])
    ordered = ["loan_id", "age", "annual_income", "employment_years",
               "home_ownership", "credit_score", "num_existing_loans",
               "num_late_payments_2yr", "loan_amount", "loan_term_months",
               "interest_rate", "debt_to_income", "loan_purpose", "region",
               "default"]
    df = df[ordered]

    out = "../data/loan_applications.csv"
    df.to_csv(out, index=False)
    rate = df["default"].mean()
    print(f"Wrote {out}: {len(df):,} rows, {df.shape[1]} columns")
    print(f"Overall default rate: {rate:.1%}")
    print(df.head())
